from django.core.validators import MaxValueValidator, MinValueValidator
from django.db import models
from django.db.models.signals import post_delete
from django.dispatch import receiver

from core.utils import delete_file, unique_slug


class SkillCategory(models.Model):
    name = models.CharField(max_length=80, unique=True)
    slug = models.SlugField(max_length=90, unique=True, blank=True)
    description = models.CharField(max_length=200, blank=True)
    order = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ['order', 'name']
        verbose_name_plural = 'Skill categories'

    def __str__(self):
        return self.name

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = unique_slug(self, self.name)
        super().save(*args, **kwargs)

    @property
    def card_icon(self):
        """Font Awesome icon for the skills card, picked from the category name."""
        n = self.name.lower()
        rules = [
            (('front', 'design'), 'fa-solid fa-table-cells-large'),
            (('database', 'data'), 'fa-solid fa-database'),
            (('back', 'server'), 'fa-solid fa-server'),
            (('program', 'develop', 'code'), 'fa-solid fa-code'),
            (('api',), 'fa-solid fa-plug'),
            (('deploy', 'devops', 'tool', 'cloud'), 'fa-solid fa-rocket'),
            (('auth', 'login'), 'fa-solid fa-key'),
            (('secur',), 'fa-solid fa-shield-halved'),
            (('test', 'quality'), 'fa-solid fa-flask'),
            (('professional', 'office', 'business'), 'fa-solid fa-briefcase'),
        ]
        for words, icon in rules:
            if any(w in n for w in words):
                return icon
        return 'fa-solid fa-layer-group'


class Skill(models.Model):
    category = models.ForeignKey(SkillCategory, on_delete=models.CASCADE, related_name='skills')
    name = models.CharField(max_length=80)
    description = models.CharField(max_length=240, blank=True)
    icon = models.ImageField(upload_to='skill_icons/', blank=True)
    icon_class = models.CharField(
        max_length=60, blank=True,
        help_text='Font Awesome classes used when no icon image is uploaded, e.g. "fa-brands fa-python".')
    proficiency = models.PositiveSmallIntegerField(
        null=True, blank=True,
        validators=[MinValueValidator(0), MaxValueValidator(100)],
        help_text='Optional percentage. Leave empty to hide the progress bar.')
    order = models.PositiveIntegerField(default=0)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ['category__order', 'category__name', 'order', 'name']
        constraints = [
            models.UniqueConstraint(fields=['category', 'name'], name='unique_skill_per_category')
        ]

    def __str__(self):
        return self.name


@receiver(post_delete, sender=Skill)
def _remove_skill_icon(sender, instance, **kwargs):
    delete_file(instance.icon)