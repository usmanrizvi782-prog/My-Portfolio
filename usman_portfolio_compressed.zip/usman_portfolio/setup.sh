#!/usr/bin/env bash
# One-command local setup for macOS / Linux.  Usage:  bash setup.sh
set -e
python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
[ -f .env ] || cp .env.example .env
python manage.py makemigrations core skills experience projects contact
python manage.py migrate
python manage.py seed_data
echo
echo "Create your Superadmin account (you will log in at /superadmin/login/):"
python manage.py createsuperuser
echo
echo "Starting the server at http://127.0.0.1:8000/"
python manage.py runserver
