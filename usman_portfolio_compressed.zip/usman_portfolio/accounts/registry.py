"""Describes every section the generic dashboard CRUD pages can manage.

Adding a new editable model to the dashboard only needs a new entry here.
"""
from core.models import SocialLink
from experience.models import Education, Experience
from projects.models import Project, Technology
from skills.models import Skill, SkillCategory

from .forms import (EducationForm, ExperienceForm, ProjectForm, SkillCategoryForm,
                    SkillForm, SocialLinkForm, TechnologyForm)

ENTITIES = {
    'projects': {
        'model': Project, 'form': ProjectForm, 'title': 'Projects', 'singular': 'Project',
        'icon': 'fa-solid fa-diagram-project',
        'columns': [('title', 'Title'), ('category', 'Category'), ('is_published', 'Published'),
                    ('featured', 'Featured'), ('is_demo', 'Sample'), ('published_date', 'Date')],
        'search': ['title', 'short_description', 'category'],
        'toggles': ['is_published', 'featured'],
        'ordered': True, 'group_field': None, 'select_related': [],
    },
    'skills': {
        'model': Skill, 'form': SkillForm, 'title': 'Skills', 'singular': 'Skill',
        'icon': 'fa-solid fa-bolt',
        'columns': [('name', 'Skill'), ('category', 'Category'), ('proficiency', 'Level %'),
                    ('order', 'Order'), ('is_active', 'Active')],
        'search': ['name', 'description', 'category__name'],
        'toggles': ['is_active'],
        'ordered': True, 'group_field': 'category', 'select_related': ['category'],
    },
    'categories': {
        'model': SkillCategory, 'form': SkillCategoryForm, 'title': 'Skill categories',
        'singular': 'Skill category', 'icon': 'fa-solid fa-layer-group',
        'columns': [('name', 'Name'), ('slug', 'Slug'), ('order', 'Order')],
        'search': ['name', 'description'], 'toggles': [],
        'ordered': True, 'group_field': None, 'select_related': [],
        'warning': 'Deleting a category also deletes every skill inside it.',
    },
    'technologies': {
        'model': Technology, 'form': TechnologyForm, 'title': 'Technologies',
        'singular': 'Technology', 'icon': 'fa-solid fa-microchip',
        'columns': [('name', 'Name'), ('slug', 'Slug')],
        'search': ['name'], 'toggles': [],
        'ordered': False, 'group_field': None, 'select_related': [],
    },
    'experience': {
        'model': Experience, 'form': ExperienceForm, 'title': 'Experience',
        'singular': 'Experience entry', 'icon': 'fa-solid fa-briefcase',
        'columns': [('role', 'Role'), ('company', 'Company'), ('period', 'Period'),
                    ('order', 'Order'), ('is_active', 'Visible')],
        'search': ['role', 'company', 'description'],
        'toggles': ['is_active'],
        'ordered': True, 'group_field': None, 'select_related': [],
    },
    'education': {
        'model': Education, 'form': EducationForm, 'title': 'Education',
        'singular': 'Education entry', 'icon': 'fa-solid fa-graduation-cap',
        'columns': [('degree', 'Qualification'), ('institution', 'Institution'),
                    ('period', 'Period'), ('order', 'Order'), ('is_active', 'Visible')],
        'search': ['degree', 'institution', 'description'],
        'toggles': ['is_active'],
        'ordered': True, 'group_field': None, 'select_related': [],
    },
    'social': {
        'model': SocialLink, 'form': SocialLinkForm, 'title': 'Social links',
        'singular': 'Social link', 'icon': 'fa-solid fa-share-nodes',
        'columns': [('name', 'Name'), ('url', 'URL'), ('order', 'Order'), ('is_active', 'Active')],
        'search': ['name', 'url'], 'toggles': ['is_active'],
        'ordered': True, 'group_field': None, 'select_related': [],
    },
}
