from functools import wraps

from django.contrib.auth.views import redirect_to_login
from django.core.exceptions import PermissionDenied
from django.urls import reverse


def staff_required(view):
    """Allow only active staff/superusers; everyone else is sent to the login page."""

    @wraps(view)
    def wrapper(request, *args, **kwargs):
        user = request.user
        if user.is_authenticated and user.is_active and user.is_staff:
            return view(request, *args, **kwargs)
        if user.is_authenticated:
            raise PermissionDenied  # logged in, but not allowed in the dashboard
        return redirect_to_login(request.get_full_path(), reverse('dash_login'))

    return wrapper
