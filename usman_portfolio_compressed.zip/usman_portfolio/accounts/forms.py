import re

from django import forms

from core.models import SiteSettings, SocialLink
from experience.models import Education, Experience
from projects.models import Project, Technology
from skills.models import Skill, SkillCategory


class StyledMixin:
    """Give every widget the CSS class the dashboard theme expects."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            widget = field.widget
            if isinstance(widget, forms.CheckboxInput):
                widget.attrs['class'] = 'check'
            elif isinstance(widget, forms.FileInput):  # includes ClearableFileInput
                widget.attrs['class'] = 'file'
            elif isinstance(widget, forms.HiddenInput):
                continue
            else:
                widget.attrs['class'] = 'input'


class SiteSettingsForm(StyledMixin, forms.ModelForm):
    class Meta:
        model = SiteSettings
        exclude = ['updated_at']
        widgets = {
            'biography': forms.Textarea(attrs={'rows': 6}),
            'interests': forms.Textarea(attrs={'rows': 5}),
            'meta_description': forms.Textarea(attrs={'rows': 2}),
        }


class SocialLinkForm(StyledMixin, forms.ModelForm):
    class Meta:
        model = SocialLink
        fields = ['name', 'url', 'icon_class', 'order', 'is_active']


class SkillCategoryForm(StyledMixin, forms.ModelForm):
    class Meta:
        model = SkillCategory
        fields = ['name', 'slug', 'description', 'order']


class SkillForm(StyledMixin, forms.ModelForm):
    class Meta:
        model = Skill
        fields = ['name', 'category', 'description', 'icon', 'icon_class',
                  'proficiency', 'order', 'is_active']
        widgets = {'description': forms.Textarea(attrs={'rows': 2})}


class TechnologyForm(StyledMixin, forms.ModelForm):
    class Meta:
        model = Technology
        fields = ['name', 'slug']


class ExperienceForm(StyledMixin, forms.ModelForm):
    class Meta:
        model = Experience
        fields = ['role', 'company', 'start_year', 'end_year', 'is_current', 'period_label',
                  'description', 'order', 'is_active']
        widgets = {'description': forms.Textarea(attrs={'rows': 7})}


class EducationForm(StyledMixin, forms.ModelForm):
    class Meta:
        model = Education
        fields = ['degree', 'institution', 'start_year', 'end_year', 'is_ongoing',
                  'period_label', 'description', 'order', 'is_active']
        widgets = {'description': forms.Textarea(attrs={'rows': 3})}


class ProjectForm(StyledMixin, forms.ModelForm):
    technology_names = forms.CharField(
        required=False, label='Technologies',
        help_text='Comma-separated, e.g. Python, Django, PostgreSQL. New names are created automatically.')

    field_order = [
        'title', 'slug', 'short_description', 'detailed_description', 'category',
        'technology_names', 'thumbnail', 'github_url', 'live_url', 'published_date',
        'order', 'featured', 'is_published', 'is_demo',
    ]

    class Meta:
        model = Project
        fields = ['title', 'slug', 'short_description', 'detailed_description', 'thumbnail',
                  'github_url', 'live_url', 'category', 'featured', 'published_date',
                  'order', 'is_published', 'is_demo']
        widgets = {
            'short_description': forms.Textarea(attrs={'rows': 2}),
            'detailed_description': forms.Textarea(attrs={'rows': 8}),
            'published_date': forms.DateInput(attrs={'type': 'date'}, format='%Y-%m-%d'),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if self.instance.pk:
            self.fields['technology_names'].initial = ', '.join(
                self.instance.technologies.values_list('name', flat=True))

    def save(self, commit=True):
        project = super().save(commit=commit)
        if commit:
            self._save_technologies(project)
        return project

    def _save_technologies(self, project):
        names = [n.strip() for n in re.split(r'[,\n]', self.cleaned_data.get('technology_names', '')) if n.strip()]
        technologies = []
        for name in names:
            tech = Technology.objects.filter(name__iexact=name).first() or Technology.objects.create(name=name)
            if tech not in technologies:
                technologies.append(tech)
        project.technologies.set(technologies)
