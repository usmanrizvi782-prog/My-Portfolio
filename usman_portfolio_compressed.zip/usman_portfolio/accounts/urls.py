from django.urls import path
from django.views.generic import RedirectView

from . import views

urlpatterns = [
    path('', RedirectView.as_view(pattern_name='dash_home', permanent=False)),
    path('login/', views.login_view, name='dash_login'),
    path('logout/', views.logout_view, name='dash_logout'),
    path('dashboard/', views.dashboard_home, name='dash_home'),
    path('settings/', views.site_settings, name='dash_settings'),

    path('messages/', views.message_list, name='dash_messages'),
    path('messages/<int:pk>/', views.message_detail, name='dash_message_detail'),
    path('messages/<int:pk>/toggle/', views.message_toggle, name='dash_message_toggle'),
    path('messages/<int:pk>/delete/', views.message_delete, name='dash_message_delete'),

    path('media/', views.media_library, name='dash_media'),
    path('media/image/<int:pk>/delete/', views.media_image_delete, name='dash_media_image_delete'),
    path('media/image/<int:pk>/replace/', views.media_image_replace, name='dash_media_image_replace'),
    path('media/unused/delete/', views.media_delete_unused, name='dash_media_delete_unused'),

    path('crud/<slug:entity>/', views.entity_list, name='dash_list'),
    path('crud/<slug:entity>/new/', views.entity_form, name='dash_create'),
    path('crud/<slug:entity>/<int:pk>/edit/', views.entity_form, name='dash_edit'),
    path('crud/<slug:entity>/<int:pk>/delete/', views.entity_delete, name='dash_delete'),
    path('crud/<slug:entity>/<int:pk>/toggle/<slug:field>/', views.entity_toggle, name='dash_toggle'),
    path('crud/<slug:entity>/<int:pk>/move/<slug:direction>/', views.entity_move, name='dash_move'),
]
