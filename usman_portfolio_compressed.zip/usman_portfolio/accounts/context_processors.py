from contact.models import ContactMessage

from .registry import ENTITIES


def dashboard(request):
    """Notification + sidebar data, computed only for dashboard pages."""
    if not request.path.startswith('/superadmin/'):
        return {}
    user = getattr(request, 'user', None)
    if not (user and user.is_authenticated and user.is_staff):
        return {}
    unread = ContactMessage.objects.filter(is_read=False)
    return {
        'unread_count': unread.count(),
        'latest_unread': list(unread[:5]),
        'dash_entities': [
            {'key': key, 'title': cfg['title'], 'icon': cfg['icon']}
            for key, cfg in ENTITIES.items()
        ],
    }
