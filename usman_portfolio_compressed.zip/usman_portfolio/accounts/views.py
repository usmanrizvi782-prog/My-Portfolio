from datetime import timedelta
from pathlib import Path

from django import forms as dj_forms
from django.conf import settings
from django.contrib import messages
from django.contrib.auth import login, logout
from django.contrib.auth.forms import AuthenticationForm
from django.core.cache import cache
from django.core.exceptions import ValidationError
from django.core.files.storage import default_storage
from django.core.paginator import Paginator
from django.db.models import Count, Max, Q
from django.db.models.functions import TruncDate
from django.http import Http404
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.utils import timezone
from django.utils.http import url_has_allowed_host_and_scheme
from django.views.decorators.cache import never_cache
from django.views.decorators.http import require_POST

from contact.models import ContactMessage
from core.models import SiteSettings
from experience.models import Education, Experience
from projects.models import Project, ProjectImage
from skills.models import Skill

from .decorators import staff_required
from .forms import SiteSettingsForm
from .registry import ENTITIES

PAGE_SIZE = 12
LOGIN_ATTEMPTS = 5
LOGIN_LOCK_SECONDS = 15 * 60


# ------------------------------------------------------------------ helpers
def _safe_next(request, default):
    target = request.POST.get('next') or request.GET.get('next') or ''
    if target and url_has_allowed_host_and_scheme(
            target, allowed_hosts={request.get_host()}, require_https=request.is_secure()):
        return target
    return default


def _client_ip(request):
    return request.META.get('REMOTE_ADDR', 'unknown')


def _get_entity(key):
    config = ENTITIES.get(key)
    if config is None:
        raise Http404('Unknown dashboard section.')
    return config


# ------------------------------------------------------------------ login / logout
@never_cache
def login_view(request):
    if request.user.is_authenticated and request.user.is_staff:
        return redirect('dash_home')

    lock_key = f'dash-login:{_client_ip(request)}'
    form = AuthenticationForm(request, data=request.POST if request.method == 'POST' else None)
    for field in form.fields.values():
        field.widget.attrs['class'] = 'input'

    if request.method == 'POST':
        attempts = cache.get(lock_key, 0)
        if attempts >= LOGIN_ATTEMPTS:
            form.add_error(None, 'Too many failed attempts. Please wait 15 minutes and try again.')
        elif form.is_valid():
            user = form.get_user()
            if user.is_staff:
                login(request, user)
                cache.delete(lock_key)
                return redirect(_safe_next(request, reverse('dash_home')))
            cache.set(lock_key, attempts + 1, LOGIN_LOCK_SECONDS)
            form.add_error(None, 'This account does not have dashboard access.')
        else:
            cache.set(lock_key, attempts + 1, LOGIN_LOCK_SECONDS)

    return render(request, 'dashboard/login.html', {'form': form, 'next': request.GET.get('next', '')})


@require_POST
def logout_view(request):
    logout(request)
    return redirect('dash_login')


# ------------------------------------------------------------------ dashboard home
@never_cache
@staff_required
def dashboard_home(request):
    today = timezone.localdate()
    start = today - timedelta(days=13)
    per_day = {
        row['day']: row['c']
        for row in ContactMessage.objects.filter(created_at__date__gte=start)
        .annotate(day=TruncDate('created_at')).values('day')
        .annotate(c=Count('id')).order_by()
    }
    days = [start + timedelta(days=i) for i in range(14)]

    project_cats = (Project.objects.exclude(category='').values('category')
                    .annotate(c=Count('id')).order_by('category'))
    skill_cats = (Skill.objects.values('category__name')
                  .annotate(c=Count('id')).order_by('category__name'))

    stats = [
        {'label': 'Total projects', 'value': Project.objects.count(), 'icon': 'fa-solid fa-diagram-project'},
        {'label': 'Published projects', 'value': Project.objects.filter(is_published=True).count(), 'icon': 'fa-solid fa-eye'},
        {'label': 'Total skills', 'value': Skill.objects.count(), 'icon': 'fa-solid fa-bolt'},
        {'label': 'Total messages', 'value': ContactMessage.objects.count(), 'icon': 'fa-solid fa-envelope'},
        {'label': 'Unread messages', 'value': ContactMessage.objects.filter(is_read=False).count(), 'icon': 'fa-solid fa-envelope-open-text'},
        {'label': 'Experience entries', 'value': Experience.objects.count(), 'icon': 'fa-solid fa-briefcase'},
    ]
    charts = {
        'messages': {'labels': [d.strftime('%d %b') for d in days],
                     'values': [per_day.get(d, 0) for d in days]},
        'projects': {'labels': [r['category'] for r in project_cats],
                     'values': [r['c'] for r in project_cats]},
        'skills': {'labels': [r['category__name'] for r in skill_cats],
                   'values': [r['c'] for r in skill_cats]},
    }
    return render(request, 'dashboard/home.html', {
        'stats': stats,
        'charts': charts,
        'recent_messages': ContactMessage.objects.all()[:5],
        'education_count': Education.objects.count(),
        'active': 'home',
    })


# ------------------------------------------------------------------ generic CRUD
def _cell(obj, attr, toggles):
    value = getattr(obj, attr)
    if isinstance(value, bool):
        return {'kind': 'bool', 'value': value, 'field': attr, 'toggle': attr in toggles}
    if value is None or value == '':
        value = '—'
    return {'kind': 'text', 'value': value}


@never_cache
@staff_required
def entity_list(request, entity):
    config = _get_entity(entity)
    queryset = config['model'].objects.all()
    if config['select_related']:
        queryset = queryset.select_related(*config['select_related'])

    query = request.GET.get('q', '').strip()
    if query:
        condition = Q()
        for field in config['search']:
            condition |= Q(**{f'{field}__icontains': query})
        queryset = queryset.filter(condition)

    filters = []
    for field in config['toggles']:
        value = request.GET.get(field, '')
        if value in ('1', '0'):
            queryset = queryset.filter(**{field: value == '1'})
        filters.append({'field': field, 'value': value,
                        'label': field.replace('is_', '').replace('_', ' ').title()})

    page = Paginator(queryset, PAGE_SIZE).get_page(request.GET.get('page'))
    rows = [
        {'obj': obj, 'cells': [_cell(obj, attr, config['toggles']) for attr, _ in config['columns']]}
        for obj in page.object_list
    ]
    params = request.GET.copy()
    params.pop('page', None)
    return render(request, 'dashboard/list.html', {
        'entity': entity, 'config': config, 'rows': rows, 'page': page,
        'headers': [label for _, label in config['columns']],
        'query': query, 'filters': filters, 'querystring': params.urlencode(),
        'can_reorder': config['ordered'] and not query,
        'active': entity,
    })


def _save_screenshots(request, project):
    """Attach every file chosen in the multi-file input as a ProjectImage."""
    checker = dj_forms.ImageField()
    next_order = (project.images.aggregate(m=Max('order'))['m'] or 0) + 1
    saved = failed = 0
    for upload in request.FILES.getlist('screenshots'):
        try:
            checker.clean(upload)
        except ValidationError:
            failed += 1
            continue
        upload.seek(0)
        ProjectImage.objects.create(project=project, image=upload, order=next_order)
        next_order += 1
        saved += 1
    if saved:
        messages.success(request, f'{saved} screenshot(s) uploaded.')
    if failed:
        messages.error(request, f'{failed} file(s) were skipped because they are not valid images.')


@never_cache
@staff_required
def entity_form(request, entity, pk=None):
    config = _get_entity(entity)
    obj = get_object_or_404(config['model'], pk=pk) if pk else None
    if request.method == 'POST':
        form = config['form'](request.POST, request.FILES, instance=obj)
        if form.is_valid():
            obj = form.save()
            if entity == 'projects':
                _save_screenshots(request, obj)
            messages.success(request, f"{config['singular']} saved.")
            return redirect('dash_list', entity=entity)
    else:
        form = config['form'](instance=obj)
    return render(request, 'dashboard/form.html', {
        'entity': entity, 'config': config, 'form': form, 'obj': obj, 'active': entity,
        'images': obj.images.all() if (entity == 'projects' and obj) else [],
    })


@never_cache
@staff_required
def entity_delete(request, entity, pk):
    config = _get_entity(entity)
    obj = get_object_or_404(config['model'], pk=pk)
    if request.method == 'POST':
        obj.delete()
        messages.success(request, f"{config['singular']} deleted.")
        return redirect('dash_list', entity=entity)
    return render(request, 'dashboard/confirm_delete.html',
                  {'entity': entity, 'config': config, 'obj': obj, 'active': entity})


@staff_required
@require_POST
def entity_toggle(request, entity, pk, field):
    config = _get_entity(entity)
    if field not in config['toggles']:
        raise Http404('This field cannot be toggled.')
    obj = get_object_or_404(config['model'], pk=pk)
    setattr(obj, field, not getattr(obj, field))
    obj.save()
    messages.success(request, f"{config['singular']} updated.")
    return redirect(_safe_next(request, reverse('dash_list', kwargs={'entity': entity})))


@staff_required
@require_POST
def entity_move(request, entity, pk, direction):
    config = _get_entity(entity)
    if not config['ordered'] or direction not in ('up', 'down'):
        raise Http404('This section cannot be reordered.')
    obj = get_object_or_404(config['model'], pk=pk)
    siblings = config['model'].objects.all()
    group = config['group_field']
    if group:
        siblings = siblings.filter(**{group: getattr(obj, group)})
    items = sorted(siblings, key=lambda item: (item.order, item.pk))
    index = next(i for i, item in enumerate(items) if item.pk == obj.pk)
    target = index - 1 if direction == 'up' else index + 1
    if 0 <= target < len(items):
        items[index], items[target] = items[target], items[index]
    for position, item in enumerate(items):
        item.order = position
    config['model'].objects.bulk_update(items, ['order'])
    return redirect(_safe_next(request, reverse('dash_list', kwargs={'entity': entity})))


# ------------------------------------------------------------------ messages
@never_cache
@staff_required
def message_list(request):
    queryset = ContactMessage.objects.all()
    query = request.GET.get('q', '').strip()
    status = request.GET.get('status', '')
    if query:
        queryset = queryset.filter(
            Q(name__icontains=query) | Q(email__icontains=query)
            | Q(subject__icontains=query) | Q(message__icontains=query))
    if status == 'unread':
        queryset = queryset.filter(is_read=False)
    elif status == 'read':
        queryset = queryset.filter(is_read=True)
    page = Paginator(queryset, PAGE_SIZE).get_page(request.GET.get('page'))
    params = request.GET.copy()
    params.pop('page', None)
    return render(request, 'dashboard/messages.html', {
        'page': page, 'query': query, 'status': status,
        'querystring': params.urlencode(), 'active': 'messages'})


@never_cache
@staff_required
def message_detail(request, pk):
    message = get_object_or_404(ContactMessage, pk=pk)
    if not message.is_read:
        message.is_read = True
        message.save(update_fields=['is_read'])
    return render(request, 'dashboard/message_detail.html', {'message_obj': message, 'active': 'messages'})


@staff_required
@require_POST
def message_toggle(request, pk):
    message = get_object_or_404(ContactMessage, pk=pk)
    message.is_read = not message.is_read
    message.save(update_fields=['is_read'])
    return redirect(_safe_next(request, reverse('dash_messages')))


@staff_required
@require_POST
def message_delete(request, pk):
    get_object_or_404(ContactMessage, pk=pk).delete()
    messages.success(request, 'Message deleted.')
    return redirect('dash_messages')


# ------------------------------------------------------------------ website settings
@never_cache
@staff_required
def site_settings(request):
    obj = SiteSettings.load()
    old_files = {name: getattr(obj, name).name for name in ('profile_picture', 'cv_file')}
    if request.method == 'POST':
        form = SiteSettingsForm(request.POST, request.FILES, instance=obj)
        if form.is_valid():
            obj = form.save()
            for name, old in old_files.items():  # remove replaced/cleared files
                if old and old != getattr(obj, name).name:
                    default_storage.delete(old)
            messages.success(request, 'Website settings saved. The public site is updated.')
            return redirect('dash_settings')
    else:
        form = SiteSettingsForm(instance=obj)
    return render(request, 'dashboard/settings.html', {'form': form, 'active': 'settings'})


# ------------------------------------------------------------------ media library
def _referenced_media():
    names = set(Project.objects.exclude(thumbnail='').values_list('thumbnail', flat=True))
    names.update(ProjectImage.objects.values_list('image', flat=True))
    names.update(Skill.objects.exclude(icon='').values_list('icon', flat=True))
    site = SiteSettings.load()
    names.update(n for n in (site.profile_picture.name, site.cv_file.name) if n)
    return {name.replace('\\', '/') for name in names}


def _unused_media():
    root = Path(settings.MEDIA_ROOT)
    if not root.exists():
        return []
    used = _referenced_media()
    unused = []
    for path in sorted(root.rglob('*')):
        if path.is_file():
            relative = path.relative_to(root).as_posix()
            if relative not in used:
                unused.append({'name': relative, 'size_kb': max(1, path.stat().st_size // 1024)})
    return unused


@never_cache
@staff_required
def media_library(request):
    return render(request, 'dashboard/media.html', {
        'site_obj': SiteSettings.load(),
        'images': ProjectImage.objects.select_related('project'),
        'unused': _unused_media(),
        'thumbnails': Project.objects.exclude(thumbnail=''),
        'active': 'media',
    })


@staff_required
@require_POST
def media_image_delete(request, pk):
    get_object_or_404(ProjectImage, pk=pk).delete()
    messages.success(request, 'Image deleted.')
    return redirect(_safe_next(request, reverse('dash_media')))


@staff_required
@require_POST
def media_image_replace(request, pk):
    image = get_object_or_404(ProjectImage, pk=pk)
    upload = request.FILES.get('image')
    try:
        if upload is None:
            raise ValidationError('Choose an image file first.')
        dj_forms.ImageField().clean(upload)
    except ValidationError as error:
        messages.error(request, ' '.join(error.messages))
        return redirect(_safe_next(request, reverse('dash_media')))
    upload.seek(0)
    old = image.image.name
    image.image = upload
    image.save()
    if old and old != image.image.name:
        default_storage.delete(old)
    messages.success(request, 'Image replaced.')
    return redirect(_safe_next(request, reverse('dash_media')))


@staff_required
@require_POST
def media_delete_unused(request):
    root = Path(settings.MEDIA_ROOT)
    removed = 0
    for item in _unused_media():
        try:
            (root / item['name']).unlink()
            removed += 1
        except OSError:
            continue
    messages.success(request, f'{removed} unused file(s) deleted.')
    return redirect('dash_media')
