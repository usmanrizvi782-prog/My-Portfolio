import os

from django.contrib.auth import get_user_model
from django.core.files.uploadedfile import SimpleUploadedFile

from contact.models import ContactMessage
from core.models import SiteSettings
from core.testing import MediaTestCase, png_upload
from experience.models import Education, Experience
from projects.models import Project, ProjectImage
from skills.models import Skill, SkillCategory

User = get_user_model()


class DashboardTestCase(MediaTestCase):
    def setUp(self):
        from django.core.cache import cache
        cache.clear()
        self.staff = User.objects.create_user('admin', 'a@example.com', 'pass12345', is_staff=True, is_superuser=True)
        self.visitor = User.objects.create_user('visitor', 'v@example.com', 'pass12345')

    def login(self):
        self.assertTrue(self.client.login(username='admin', password='pass12345'))


class AccessTests(DashboardTestCase):
    def test_dashboard_requires_login(self):
        response = self.client.get('/superadmin/dashboard/')
        self.assertRedirects(response, '/superadmin/login/?next=/superadmin/dashboard/',
                             fetch_redirect_response=False)

    def test_every_dashboard_route_is_protected(self):
        for url in ('/superadmin/settings/', '/superadmin/messages/', '/superadmin/media/',
                    '/superadmin/crud/projects/', '/superadmin/crud/projects/new/',
                    '/superadmin/crud/skills/', '/superadmin/crud/experience/'):
            response = self.client.get(url)
            self.assertEqual(response.status_code, 302, url)
            self.assertIn('/superadmin/login/', response['Location'])

    def test_non_staff_user_is_forbidden(self):
        self.client.login(username='visitor', password='pass12345')
        self.assertEqual(self.client.get('/superadmin/dashboard/').status_code, 403)

    def test_staff_login_and_logout(self):
        response = self.client.post('/superadmin/login/', {'username': 'admin', 'password': 'pass12345'})
        self.assertRedirects(response, '/superadmin/dashboard/', fetch_redirect_response=False)
        dashboard = self.client.get('/superadmin/dashboard/')
        self.assertContains(dashboard, 'Total projects')
        self.assertContains(dashboard, 'Unread messages')
        self.assertEqual(self.client.get('/superadmin/logout/').status_code, 405)  # POST only
        self.client.post('/superadmin/logout/')
        self.assertEqual(self.client.get('/superadmin/dashboard/').status_code, 302)

    def test_login_rejects_wrong_password_and_non_staff(self):
        bad = self.client.post('/superadmin/login/', {'username': 'admin', 'password': 'wrong'})
        self.assertEqual(bad.status_code, 200)
        nonstaff = self.client.post('/superadmin/login/', {'username': 'visitor', 'password': 'pass12345'})
        self.assertContains(nonstaff, 'does not have dashboard access')

    def test_login_locks_after_repeated_failures(self):
        from django.core.cache import cache
        cache.clear()
        for _ in range(5):
            self.client.post('/superadmin/login/', {'username': 'admin', 'password': 'wrong'})
        locked = self.client.post('/superadmin/login/', {'username': 'admin', 'password': 'pass12345'})
        self.assertContains(locked, 'Too many failed attempts')
        cache.clear()

    def test_dashboard_has_no_whatsapp_button(self):
        self.login()
        self.assertNotContains(self.client.get('/superadmin/dashboard/'), 'wa.me')

    def test_open_redirect_is_blocked(self):
        response = self.client.post('/superadmin/login/?next=https://evil.example/',
                                    {'username': 'admin', 'password': 'pass12345', 'next': 'https://evil.example/'})
        self.assertRedirects(response, '/superadmin/dashboard/', fetch_redirect_response=False)


class ProjectManagementTests(DashboardTestCase):
    def project_data(self, **extra):
        data = {
            'title': 'Demo shop', 'slug': '', 'short_description': 'A shop', 'detailed_description': 'Long text',
            'category': 'Web', 'technology_names': 'Python, Django, python', 'github_url': '',
            'live_url': 'https://example.com', 'published_date': '2026-01-15', 'order': '1',
            'is_published': 'on',
        }
        data.update(extra)
        return data

    def test_create_edit_toggle_delete_project(self):
        self.login()
        response = self.client.post('/superadmin/crud/projects/new/', self.project_data(
            thumbnail=png_upload('thumb.png'), screenshots=[png_upload('a.png'), png_upload('b.png')]))
        self.assertRedirects(response, '/superadmin/crud/projects/', fetch_redirect_response=False)
        project = Project.objects.get()
        self.assertEqual(project.slug, 'demo-shop')
        self.assertEqual(sorted(project.technologies.values_list('name', flat=True)), ['Django', 'Python'])
        self.assertEqual(project.images.count(), 2)
        self.assertTrue(os.path.exists(project.thumbnail.path))
        self.assertTrue(project.is_published)

        # public site reflects it
        self.assertContains(self.client.get('/'), 'Demo shop')

        # edit
        edit_url = f'/superadmin/crud/projects/{project.pk}/edit/'
        self.assertContains(self.client.get(edit_url), 'Demo shop')
        self.client.post(edit_url, self.project_data(title='Renamed shop', slug='demo-shop'))
        project.refresh_from_db()
        self.assertEqual(project.title, 'Renamed shop')

        # toggles
        self.client.post(f'/superadmin/crud/projects/{project.pk}/toggle/featured/')
        project.refresh_from_db()
        self.assertTrue(project.featured)
        self.client.post(f'/superadmin/crud/projects/{project.pk}/toggle/is_published/')
        project.refresh_from_db()
        self.assertFalse(project.is_published)
        self.assertNotContains(self.client.get('/'), 'Renamed shop')
        self.assertEqual(self.client.post(f'/superadmin/crud/projects/{project.pk}/toggle/title/').status_code, 404)

        # delete removes the files too
        thumb_path = project.thumbnail.path
        shot_paths = [image.image.path for image in project.images.all()]
        self.assertEqual(self.client.get(f'/superadmin/crud/projects/{project.pk}/delete/').status_code, 200)
        self.client.post(f'/superadmin/crud/projects/{project.pk}/delete/')
        self.assertEqual(Project.objects.count(), 0)
        self.assertFalse(os.path.exists(thumb_path))
        self.assertFalse(any(os.path.exists(p) for p in shot_paths))

    def test_invalid_image_is_rejected_and_bad_screenshot_skipped(self):
        self.login()
        bad = SimpleUploadedFile('fake.png', b'not an image', content_type='image/png')
        response = self.client.post('/superadmin/crud/projects/new/', self.project_data(thumbnail=bad))
        self.assertEqual(response.status_code, 200)
        self.assertEqual(Project.objects.count(), 0)
        self.client.post('/superadmin/crud/projects/new/', self.project_data(
            screenshots=[SimpleUploadedFile('x.png', b'nope', content_type='image/png'), png_upload('ok.png')]))
        self.assertEqual(Project.objects.get().images.count(), 1)

    def test_search_and_filter_in_list(self):
        self.login()
        Project.objects.create(title='Alpha', short_description='a', is_published=True)
        Project.objects.create(title='Beta', short_description='b', is_published=False)
        self.assertContains(self.client.get('/superadmin/crud/projects/?q=alp'), 'Alpha')
        self.assertNotContains(self.client.get('/superadmin/crud/projects/?q=alp'), 'Beta')
        unpublished = self.client.get('/superadmin/crud/projects/?is_published=0')
        self.assertContains(unpublished, 'Beta')
        self.assertNotContains(unpublished, 'Alpha')

    def test_unknown_entity_is_404(self):
        self.login()
        self.assertEqual(self.client.get('/superadmin/crud/nothing/').status_code, 404)


class SkillExperienceEducationTests(DashboardTestCase):
    def test_skill_category_and_skill_management(self):
        self.login()
        self.client.post('/superadmin/crud/categories/new/', {'name': 'Languages', 'slug': '', 'description': '', 'order': '1'})
        category = SkillCategory.objects.get()
        self.client.post('/superadmin/crud/skills/new/', {
            'name': 'Python', 'category': category.pk, 'description': 'Backend', 'icon_class': 'fa-brands fa-python',
            'proficiency': '', 'order': '0', 'is_active': 'on', 'icon': png_upload('icon.png')})
        skill = Skill.objects.get()
        self.assertIsNone(skill.proficiency)
        self.assertTrue(os.path.exists(skill.icon.path))
        self.client.post('/superadmin/crud/skills/new/', {
            'name': 'Django', 'category': category.pk, 'description': '', 'icon_class': '',
            'proficiency': '85', 'order': '1', 'is_active': 'on'})
        django_skill = Skill.objects.get(name='Django')
        self.assertEqual(django_skill.proficiency, 85)

        # move + reorder
        self.client.post(f'/superadmin/crud/skills/{django_skill.pk}/move/up/')
        self.assertEqual([s.name for s in Skill.objects.all()], ['Django', 'Python'])

        # change category via edit and deactivate
        other = SkillCategory.objects.create(name='Tools')
        self.client.post(f'/superadmin/crud/skills/{skill.pk}/edit/', {
            'name': 'Python', 'category': other.pk, 'description': 'Backend', 'icon_class': '',
            'proficiency': '', 'order': '0', 'is_active': 'on'})
        skill.refresh_from_db()
        self.assertEqual(skill.category, other)
        self.client.post(f'/superadmin/crud/skills/{skill.pk}/toggle/is_active/')
        skill.refresh_from_db()
        self.assertFalse(skill.is_active)

        icon_path = skill.icon.path
        self.client.post(f'/superadmin/crud/skills/{skill.pk}/delete/')
        self.assertFalse(Skill.objects.filter(pk=skill.pk).exists())
        self.assertFalse(os.path.exists(icon_path))

    def test_experience_management_and_validation(self):
        self.login()
        self.client.post('/superadmin/crud/experience/new/', {
            'role': 'Computer Operator', 'company': 'SNGPL', 'start_year': '2025', 'end_year': '',
            'is_current': 'on', 'period_label': '', 'description': 'One\nTwo', 'order': '1', 'is_active': 'on'})
        job = Experience.objects.get()
        self.assertEqual(job.period, '2025 – Present')
        self.assertEqual(job.bullets, ['One', 'Two'])
        bad = self.client.post('/superadmin/crud/experience/new/', {
            'role': 'X', 'company': 'Y', 'start_year': '2025', 'end_year': '2020', 'description': '', 'order': '0'})
        self.assertEqual(bad.status_code, 200)
        self.assertEqual(Experience.objects.count(), 1)
        self.client.post(f'/superadmin/crud/experience/{job.pk}/delete/')
        self.assertEqual(Experience.objects.count(), 0)

    def test_education_management(self):
        self.login()
        self.client.post('/superadmin/crud/education/new/', {
            'degree': 'Economics with Data Science', 'institution': 'GC University', 'start_year': '2026',
            'end_year': '', 'period_label': '2026...', 'description': '', 'order': '3', 'is_active': 'on'})
        item = Education.objects.get()
        self.assertEqual(item.period, '2026...')
        self.assertContains(self.client.get('/'), 'GC University')
        self.client.post(f'/superadmin/crud/education/{item.pk}/edit/', {
            'degree': 'Economics with Data Science', 'institution': 'GC University', 'start_year': '2026',
            'end_year': '', 'period_label': '', 'description': '', 'order': '3', 'is_active': 'on'})
        item.refresh_from_db()
        self.assertEqual(item.period, '2026')


class MessageTests(DashboardTestCase):
    def setUp(self):
        super().setUp()
        self.first = ContactMessage.objects.create(name='Ali', email='ali@example.com', subject='Project idea', message='Hello there')
        self.second = ContactMessage.objects.create(name='Sara', email='sara@example.com', subject='Job offer', message='We are hiring')
        self.login()

    def test_list_search_and_status_filter(self):
        self.assertContains(self.client.get('/superadmin/messages/'), 'Project idea')
        found = self.client.get('/superadmin/messages/?q=hiring')
        self.assertContains(found, 'Job offer')
        self.assertNotContains(found, 'Project idea')

    def test_opening_marks_read_and_toggle_and_delete(self):
        self.assertFalse(self.first.is_read)
        self.assertContains(self.client.get(f'/superadmin/messages/{self.first.pk}/'), 'Hello there')
        self.first.refresh_from_db()
        self.assertTrue(self.first.is_read)
        unread = self.client.get('/superadmin/messages/?status=unread')
        self.assertNotContains(unread, 'Project idea')
        self.client.post(f'/superadmin/messages/{self.first.pk}/toggle/')
        self.first.refresh_from_db()
        self.assertFalse(self.first.is_read)
        self.client.post(f'/superadmin/messages/{self.second.pk}/delete/')
        self.assertEqual(ContactMessage.objects.count(), 1)

    def test_delete_requires_post(self):
        self.assertEqual(self.client.get(f'/superadmin/messages/{self.first.pk}/delete/').status_code, 405)


class SettingsAndMediaTests(DashboardTestCase):
    def settings_data(self, **extra):
        data = {
            'site_title': 'My portfolio', 'meta_description': 'Desc', 'default_theme': 'dark',
            'hero_name': 'MUHAMMAD USMAN', 'hero_title': 'PYTHON DEVELOPER', 'hero_tagline': 'Hello world',
            'biography': 'Bio text', 'interests': 'Python\nDjango', 'email': 'new@example.com',
            'phone': '+92-300-0000000', 'whatsapp_number': '+92 301 1234567',
            'show_about': 'on', 'show_skills': 'on', 'show_experience': 'on',
            'show_education': 'on', 'show_projects': 'on', 'show_contact': 'on',
        }
        data.update(extra)
        return data

    def test_settings_update_public_site(self):
        self.login()
        response = self.client.post('/superadmin/settings/', self.settings_data(profile_picture=png_upload('me.png')))
        self.assertRedirects(response, '/superadmin/settings/', fetch_redirect_response=False)
        site = SiteSettings.load()
        self.assertEqual(site.whatsapp_number, '923011234567')
        home = self.client.get('/')
        self.assertContains(home, 'Hello world')
        self.assertContains(home, 'https://wa.me/923011234567')
        self.assertContains(home, 'new@example.com')
        self.assertContains(home, '<title>My portfolio</title>')
        self.assertContains(home, site.profile_picture.url)

    def test_hide_section_from_settings(self):
        self.login()
        data = self.settings_data()
        del data['show_skills']
        self.client.post('/superadmin/settings/', data)
        self.assertNotContains(self.client.get('/'), 'id="skills"')

    def test_cv_upload_and_download(self):
        self.login()
        pdf = SimpleUploadedFile('cv.pdf', b'%PDF-1.4 test cv', content_type='application/pdf')
        self.client.post('/superadmin/settings/', self.settings_data(cv_file=pdf))
        response = self.client.get('/download-cv/')
        self.assertEqual(response.status_code, 200)
        self.assertIn('attachment', response['Content-Disposition'])
        self.assertEqual(b''.join(response.streaming_content), b'%PDF-1.4 test cv')

    def test_cv_must_be_pdf(self):
        self.login()
        exe = SimpleUploadedFile('cv.exe', b'MZ', content_type='application/octet-stream')
        response = self.client.post('/superadmin/settings/', self.settings_data(cv_file=exe))
        self.assertEqual(response.status_code, 200)
        self.assertFalse(SiteSettings.load().cv_file)

    def test_invalid_whatsapp_number_is_rejected(self):
        self.login()
        response = self.client.post('/superadmin/settings/', self.settings_data(whatsapp_number='12'))
        self.assertEqual(response.status_code, 200)
        self.assertEqual(SiteSettings.load().whatsapp_number, '923700295134')

    def test_media_library_replace_delete_and_unused_cleanup(self):
        self.login()
        project = Project.objects.create(title='P', short_description='s')
        image = ProjectImage.objects.create(project=project, image=png_upload('one.png'))
        old_path = image.image.path

        self.client.post(f'/superadmin/media/image/{image.pk}/replace/', {'image': png_upload('two.png', 'red')})
        image.refresh_from_db()
        self.assertNotEqual(image.image.path, old_path)
        self.assertFalse(os.path.exists(old_path))

        stray = os.path.join(self._media_dir, 'stray.txt')
        with open(stray, 'w') as handle:
            handle.write('x')
        self.assertContains(self.client.get('/superadmin/media/'), 'stray.txt')
        self.client.post('/superadmin/media/unused/delete/')
        self.assertFalse(os.path.exists(stray))
        self.assertTrue(os.path.exists(image.image.path))  # files in use survive

        self.client.post(f'/superadmin/media/image/{image.pk}/delete/')
        self.assertEqual(ProjectImage.objects.count(), 0)
