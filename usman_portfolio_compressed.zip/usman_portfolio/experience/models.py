from django.core.exceptions import ValidationError
from django.core.validators import MaxValueValidator, MinValueValidator
from django.db import models

YEAR_VALIDATORS = [MinValueValidator(1990), MaxValueValidator(2100)]


class _PeriodMixin(models.Model):
    """Shared date handling: either type a free-text label or give years."""

    start_year = models.PositiveSmallIntegerField(null=True, blank=True, validators=YEAR_VALIDATORS)
    end_year = models.PositiveSmallIntegerField(null=True, blank=True, validators=YEAR_VALIDATORS)
    period_label = models.CharField(
        max_length=60, blank=True,
        help_text='Optional text shown instead of the years, e.g. "2026...". Leave empty to use the years.')

    class Meta:
        abstract = True

    ongoing_word = 'Present'

    def _is_ongoing(self):
        raise NotImplementedError

    @property
    def period(self):
        if self.period_label:
            return self.period_label
        if self.start_year and self._is_ongoing():
            return f'{self.start_year} – {self.ongoing_word}'
        if self.start_year and self.end_year and self.end_year != self.start_year:
            return f'{self.start_year} – {self.end_year}'
        if self.start_year:
            return str(self.start_year)
        return ''

    def _clean_years(self):
        if self.start_year and self.end_year and self.end_year < self.start_year:
            raise ValidationError({'end_year': 'The end year cannot be earlier than the start year.'})


class Experience(_PeriodMixin):
    role = models.CharField(max_length=120)
    company = models.CharField(max_length=120)
    is_current = models.BooleanField(default=False, help_text='Currently working here.')
    description = models.TextField(blank=True, help_text='One responsibility per line.')
    order = models.PositiveIntegerField(default=0)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ['order', '-start_year']
        verbose_name_plural = 'Experience'

    def __str__(self):
        return f'{self.role} – {self.company}'

    def _is_ongoing(self):
        return self.is_current

    def clean(self):
        self._clean_years()
        if self.is_current and self.end_year:
            raise ValidationError({'end_year': 'Remove the end year for a current position.'})

    @property
    def bullets(self):
        return [line.strip() for line in self.description.splitlines() if line.strip()]


class Education(_PeriodMixin):
    degree = models.CharField(max_length=160)
    institution = models.CharField(max_length=160)
    is_ongoing = models.BooleanField(default=False, help_text='Still studying here.')
    description = models.TextField(blank=True)
    order = models.PositiveIntegerField(default=0)
    is_active = models.BooleanField(default=True)

    ongoing_word = 'Ongoing'

    class Meta:
        ordering = ['order', '-start_year']
        verbose_name_plural = 'Education'

    def __str__(self):
        return f'{self.degree} – {self.institution}'

    def _is_ongoing(self):
        return self.is_ongoing

    def clean(self):
        self._clean_years()
        if self.is_ongoing and self.end_year:
            raise ValidationError({'end_year': 'Remove the end year while the study is ongoing.'})
