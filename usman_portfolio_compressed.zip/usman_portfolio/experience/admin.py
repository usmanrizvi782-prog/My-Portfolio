from django.contrib import admin

from .models import Education, Experience


@admin.register(Experience)
class ExperienceAdmin(admin.ModelAdmin):
    list_display = ('role', 'company', 'period', 'order', 'is_active')
    list_editable = ('order', 'is_active')


@admin.register(Education)
class EducationAdmin(admin.ModelAdmin):
    list_display = ('degree', 'institution', 'period', 'order', 'is_active')
    list_editable = ('order', 'is_active')
