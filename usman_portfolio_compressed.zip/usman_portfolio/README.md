# Muhammad Usman – 3D Django Portfolio

A database-driven portfolio with a Three.js hero, GSAP animations, dark/light themes,
a floating WhatsApp button and a custom **Superadmin dashboard**. Every section of the
public site (hero text, biography, skills, experience, education, projects, contact
details, photo, CV) is stored in the database and edited from the dashboard.

## 1. Quick start

You need Python 3.10+ and an internet connection (Three.js, GSAP, Font Awesome, Chart.js
and Google Fonts are loaded from CDNs).

**Windows:** double-click `setup.bat` (or run it in a terminal).
**macOS / Linux:** `bash setup.sh`

The script creates a virtual environment, installs `requirements.txt`, creates `.env`,
generates and applies the migrations, loads the CV content, asks you to create the
Superadmin account and starts the server.

Manual version of the same steps:

```bash
python -m venv venv
venv\Scripts\activate            # Windows   (macOS/Linux: source venv/bin/activate)
pip install -r requirements.txt
copy .env.example .env           # macOS/Linux: cp .env.example .env
python manage.py makemigrations core skills experience projects contact
python manage.py migrate
python manage.py seed_data       # loads the CV content, photo, CV PDF and sample projects
python manage.py createsuperuser # your Superadmin login
python manage.py runserver
```

* Website: http://127.0.0.1:8000/
* Superadmin login: http://127.0.0.1:8000/superadmin/login/
* Dashboard: http://127.0.0.1:8000/superadmin/dashboard/
* Django's own admin (backup): http://127.0.0.1:8000/django-admin/

`createsuperuser` makes a user with `is_staff` and `is_superuser`; only staff accounts can enter
the dashboard. `seed_data` never overwrites rows, so it is safe to run again.

## 2. Using the dashboard

| Sidebar item | What you can do |
|---|---|
| Dashboard | Six counters, charts, latest messages, quick actions |
| Projects | Create / edit / delete, thumbnail + several screenshots, technologies (comma-separated), GitHub and live URLs, featured, publish / unpublish, display order |
| Skills, Skill categories | Add / edit / delete, move up/down, icon image or Font Awesome class, optional percentage, activate / deactivate |
| Technologies | Tags used by projects |
| Experience, Education | Add / edit / delete, years or a custom period text such as `2026...`, order, show / hide |
| Messages | Search, read / unread, delete, reply by email |
| Social links | Icons shown in the footer |
| Media | Replace or delete screenshots, see the profile photo and CV, remove unused files |
| Website settings | Title, SEO description, hero text, biography, interests, email, phone, WhatsApp number, profile picture, CV PDF, default theme, show / hide sections |

Skill percentages are only shown if you type one. Projects marked **Sample project** are demo
ideas; untick “Sample” once a project is real.

## 3. Project structure

```
config/        settings, root URLs, WSGI/ASGI
core/          SiteSettings, SocialLink, home view, sitemap, robots, seed_data command
accounts/      Superadmin login, dashboard, generic CRUD (registry.py), media library
skills/        SkillCategory, Skill
experience/    Experience, Education
projects/      Technology, Project, ProjectImage, detail page
contact/       ContactMessage, form with spam protection, e-mail notification
templates/     public/ (site) and dashboard/ (admin) templates
static/        css/, js/ (public.js, hero3d.js, dashboard.js), images/
seed_assets/   profile photo, CV PDF and placeholder project thumbnails
```

## 4. Tests

```bash
python manage.py test
```

Covers: admin login/logout, unauthorized access, project / skill / experience / education CRUD,
image upload and deletion, CV upload and download, contact form (validation, honeypot, timing,
rate limit, email), WhatsApp link on public pages (and not in the dashboard), theme markup,
sitemap and robots, settings changes appearing on the public site.

## 5. Contact form and e-mail

Messages are always saved in the database. For e-mail notifications put SMTP details in `.env`:

```
EMAIL_BACKEND=django.core.mail.backends.smtp.EmailBackend
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_HOST_USER=you@gmail.com
EMAIL_HOST_PASSWORD=your-app-password
EMAIL_USE_TLS=True
```

The notification goes to the e-mail address set in Website settings. By default (console backend)
the e-mail is printed in the terminal. Spam protection: hidden honeypot field, signed timestamp
(rejects instant submissions), and a limit of 5 messages per hour per IP address.

## 6. Deploying

1. Server: Ubuntu + Python 3.10+, PostgreSQL, Nginx.
2. Copy the project, create a virtual environment, `pip install -r requirements.txt`.
3. Create `.env` with at least:
   ```
   DJANGO_DEBUG=False
   DJANGO_SECRET_KEY=<long random string>
   DJANGO_ALLOWED_HOSTS=yourdomain.com,www.yourdomain.com
   DJANGO_CSRF_TRUSTED_ORIGINS=https://yourdomain.com,https://www.yourdomain.com
   DB_ENGINE=postgres
   DB_NAME=portfolio
   DB_USER=portfolio
   DB_PASSWORD=<password>
   DB_HOST=localhost
   ```
   Generate a key with `python -c "from django.core.management.utils import get_random_secret_key as k; print(k())"`.
4. `python manage.py makemigrations core skills experience projects contact` (if the migration files
   are not in the project yet), then `python manage.py migrate`, `python manage.py seed_data`,
   `python manage.py createsuperuser`, `python manage.py collectstatic --noinput`.
5. Run with Gunicorn: `gunicorn config.wsgi:application --bind 127.0.0.1:8000 --workers 3`
   (use systemd to keep it running).
6. Nginx serves `/media/` (uploads) and proxies everything else; static files are served by WhiteNoise:
   ```nginx
   server {
       server_name yourdomain.com www.yourdomain.com;
       client_max_body_size 12M;
       location /media/ { alias /path/to/project/media/; expires 30d; }
       location / {
           proxy_pass http://127.0.0.1:8000;
           proxy_set_header Host $host;
           proxy_set_header X-Forwarded-Proto $scheme;
           proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
       }
   }
   ```
7. Add HTTPS with Certbot (`sudo certbot --nginx`). With `DJANGO_DEBUG=False` the project turns on
   SSL redirect, secure cookies, HSTS, no-sniff and `X-Frame-Options: DENY`.
8. Check: `python manage.py check --deploy`.

Rate limiting and the login lock-out use Django's cache. The default per-process cache works for one
Gunicorn worker; with several workers configure a shared cache (Redis or database cache) in `CACHES`.

## 7. Customising

* Colours and fonts: variables at the top of `static/css/public.css` (`:root` and `[data-theme="light"]`).
* 3D scene: `static/js/hero3d.js` (laptop, floating objects, particles, lighting).
* New dashboard section: add a model + `ModelForm`, then one entry in `accounts/registry.py`.
