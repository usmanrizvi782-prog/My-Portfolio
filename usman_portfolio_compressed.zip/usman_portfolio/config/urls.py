"""Root URL configuration."""
from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.contrib.sitemaps.views import sitemap
from django.urls import include, path

from core.sitemaps import ProjectSitemap, StaticViewSitemap
from core.views import robots_txt

sitemaps = {'static': StaticViewSitemap, 'projects': ProjectSitemap}

urlpatterns = [
    path('django-admin/', admin.site.urls),  # Django's built-in admin (optional backup)
    path('superadmin/', include('accounts.urls')),  # our custom Superadmin dashboard
    path('sitemap.xml', sitemap, {'sitemaps': sitemaps}, name='sitemap'),
    path('robots.txt', robots_txt, name='robots'),
    path('projects/', include('projects.urls')),
    path('contact/', include('contact.urls')),
    path('', include('core.urls')),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

handler404 = 'core.views.error_404'
