import re

from django.core.exceptions import ValidationError
from django.core.validators import FileExtensionValidator
from django.db import models


class SiteSettings(models.Model):
    """Single-row table that holds every editable piece of site-wide content."""

    THEME_CHOICES = [('dark', 'Dark'), ('light', 'Light')]

    site_title = models.CharField(
        max_length=120, default='Muhammad Usman | Full Stack Python Developer')
    meta_description = models.CharField(
        max_length=300,
        default='Portfolio of Muhammad Usman, a Python and Django developer '
                'building modern, user-friendly web applications.')

    hero_name = models.CharField(max_length=120, default='MUHAMMAD USMAN')
    hero_title = models.CharField(max_length=120, default='FULL STACK PYTHON DEVELOPER')
    hero_tagline = models.CharField(
        max_length=200, default='Building Modern Digital Experiences with Python & Django.')

    biography = models.TextField(
        default='I am Muhammad Usman, a Python Developer interested in building modern, '
                'scalable, and user-friendly web applications. My experience includes Python '
                'and Django development, database-driven applications, e-commerce operations, '
                'data management, and digital technologies. I continuously work on improving '
                'my development skills and creating practical digital solutions.')
    interests = models.TextField(
        blank=True, help_text='Professional interests, one per line.')

    email = models.EmailField(default='usmanrizvi561@gmail.com')
    phone = models.CharField(max_length=30, default='+92-3700295134')
    whatsapp_number = models.CharField(
        max_length=24, default='923700295134',
        help_text='International format, e.g. 923700295134 (digits only; a + or dashes are removed).')

    profile_picture = models.ImageField(upload_to='profile/', blank=True)
    cv_file = models.FileField(
        upload_to='cv/', blank=True,
        validators=[FileExtensionValidator(['pdf'])], help_text='PDF only.')

    show_about = models.BooleanField(default=True)
    show_skills = models.BooleanField(default=True)
    show_experience = models.BooleanField(default=True)
    show_education = models.BooleanField(default=True)
    show_projects = models.BooleanField(default=True)
    show_contact = models.BooleanField(default=True)

    default_theme = models.CharField(
        max_length=5, choices=THEME_CHOICES, default='dark',
        help_text='Theme for first-time visitors. Returning visitors keep their own choice.')
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = 'Site settings'
        verbose_name_plural = 'Site settings'

    def __str__(self):
        return 'Site settings'

    def clean(self):
        digits = re.sub(r'\D', '', self.whatsapp_number or '')
        if not 8 <= len(digits) <= 15:
            raise ValidationError(
                {'whatsapp_number': 'Enter the number in international format, e.g. 923700295134.'})
        self.whatsapp_number = digits

    def save(self, *args, **kwargs):
        self.pk = 1  # there is only ever one settings row
        super().save(*args, **kwargs)

    def delete(self, *args, **kwargs):  # the settings row must always exist
        return (0, {})

    @classmethod
    def load(cls):
        obj, _ = cls.objects.get_or_create(pk=1)
        return obj

    # -- helpers used by templates
    @property
    def whatsapp_digits(self):
        return re.sub(r'\D', '', self.whatsapp_number or '')

    @property
    def whatsapp_url(self):
        return f'https://wa.me/{self.whatsapp_digits}'

    @property
    def phone_href(self):
        return 'tel:+' + re.sub(r'\D', '', self.phone or '') if self.phone else ''

    @property
    def interests_list(self):
        return [line.strip() for line in self.interests.splitlines() if line.strip()]


class SocialLink(models.Model):
    name = models.CharField(max_length=60)
    url = models.URLField()
    icon_class = models.CharField(
        max_length=60, default='fa-solid fa-link',
        help_text='Font Awesome classes, e.g. "fa-brands fa-github".')
    order = models.PositiveIntegerField(default=0)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ['order', 'name']

    def __str__(self):
        return self.name
