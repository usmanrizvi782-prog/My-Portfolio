from datetime import date

from django.test import TestCase

from experience.models import Education, Experience
from projects.models import Project
from skills.models import Skill, SkillCategory

from .models import SiteSettings


class PublicSiteTests(TestCase):
    def test_home_renders_with_default_content(self):
        response = self.client.get('/')
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'MUHAMMAD USMAN')
        self.assertContains(response, 'FULL STACK PYTHON DEVELOPER')
        self.assertContains(response, 'Explore My Work')
        self.assertContains(response, 'Download My CV')
        self.assertContains(response, "Let's Connect")

    def test_whatsapp_button_is_on_every_public_page(self):
        project = Project.objects.create(title='Demo', short_description='d')
        for url in ('/', project.get_absolute_url()):
            response = self.client.get(url)
            self.assertContains(response, 'href="https://wa.me/923700295134"')
            self.assertContains(response, 'Chat with Me')
        missing = self.client.get('/does-not-exist/')
        self.assertContains(missing, 'wa.me/923700295134', status_code=404)

    def test_theme_toggle_and_saved_preference_script_present(self):
        response = self.client.get('/')
        self.assertContains(response, 'id="theme-toggle"')
        self.assertContains(response, "localStorage.getItem('theme')")
        self.assertContains(response, 'data-theme="dark"')  # dark is the default

    def test_sections_can_be_switched_off(self):
        settings_obj = SiteSettings.load()
        settings_obj.show_skills = False
        settings_obj.save()
        response = self.client.get('/')
        self.assertNotContains(response, 'id="skills"')
        self.assertContains(response, 'id="projects"')

    def test_content_comes_from_the_database(self):
        category = SkillCategory.objects.create(name='Languages')
        Skill.objects.create(category=category, name='Python', proficiency=None)
        Skill.objects.create(category=category, name='Hidden skill', is_active=False)
        Experience.objects.create(role='Dev', company='Acme', start_year=2025, is_current=True,
                                  description='Built things\nFixed things')
        Education.objects.create(degree='Economics with Data Science', institution='GC University',
                                 period_label='2026...')
        Project.objects.create(title='Visible', short_description='yes', is_published=True)
        Project.objects.create(title='Secret', short_description='no', is_published=False)
        response = self.client.get('/')
        self.assertContains(response, 'Python')
        self.assertNotContains(response, 'Hidden skill')
        self.assertNotContains(response, 'class="meter"')  # no invented percentages
        self.assertContains(response, 'Acme')
        self.assertContains(response, '2025 – Present')
        self.assertContains(response, 'Fixed things')
        self.assertContains(response, '2026...')
        self.assertContains(response, 'Visible')
        self.assertNotContains(response, 'Secret')

    def test_proficiency_only_shown_when_entered(self):
        category = SkillCategory.objects.create(name='Languages')
        Skill.objects.create(category=category, name='Python', proficiency=80)
        self.assertContains(self.client.get('/'), 'class="meter"')

    def test_project_detail_and_unpublished_404(self):
        live = Project.objects.create(title='Live one', short_description='s', is_demo=True,
                                      detailed_description='Line one\nLine two')
        hidden = Project.objects.create(title='Hidden one', short_description='s', is_published=False)
        response = self.client.get(live.get_absolute_url())
        self.assertContains(response, 'Live one')
        self.assertContains(response, 'Sample project')
        self.assertEqual(self.client.get(hidden.get_absolute_url()).status_code, 404)

    def test_project_slug_is_unique(self):
        first = Project.objects.create(title='Same title', short_description='a')
        second = Project.objects.create(title='Same title', short_description='b')
        self.assertNotEqual(first.slug, second.slug)

    def test_sitemap_and_robots(self):
        Project.objects.create(title='In map', short_description='s', published_date=date(2026, 1, 1))
        Project.objects.create(title='Not in map', short_description='s', is_published=False)
        sitemap = self.client.get('/sitemap.xml')
        self.assertEqual(sitemap.status_code, 200)
        self.assertContains(sitemap, '/projects/in-map/')
        self.assertNotContains(sitemap, 'not-in-map')
        robots = self.client.get('/robots.txt')
        self.assertContains(robots, 'Disallow: /superadmin/')
        self.assertContains(robots, 'Sitemap:')

    def test_download_cv_without_file_is_404(self):
        self.assertEqual(self.client.get('/download-cv/').status_code, 404)

    def test_whatsapp_number_is_normalised(self):
        from django.core.exceptions import ValidationError
        obj = SiteSettings.load()
        obj.whatsapp_number = '+92 370-0295134'
        obj.full_clean()
        self.assertEqual(obj.whatsapp_number, '923700295134')
        obj.whatsapp_number = '123'
        with self.assertRaises(ValidationError):
            obj.full_clean()

    def test_experience_and_education_year_validation(self):
        from django.core.exceptions import ValidationError
        with self.assertRaises(ValidationError):
            Experience(role='x', company='y', start_year=2025, end_year=2020).full_clean()
        with self.assertRaises(ValidationError):
            Education(degree='x', institution='y', start_year=2026, is_ongoing=True, end_year=2027).full_clean()
