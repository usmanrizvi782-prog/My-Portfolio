from .models import SiteSettings, SocialLink


def site(request):
    """Make site settings, navigation and social links available to every template."""
    settings_obj = SiteSettings.load()
    nav = [{'label': 'Home', 'anchor': 'home'}]
    if settings_obj.show_about:
        nav.append({'label': 'About', 'anchor': 'about'})
    if settings_obj.show_skills:
        nav.append({'label': 'Skills', 'anchor': 'skills'})
    if settings_obj.show_experience or settings_obj.show_education:
        nav.append({'label': 'Experience', 'anchor': 'experience'})
    if settings_obj.show_projects:
        nav.append({'label': 'Projects', 'anchor': 'projects'})
    if settings_obj.show_contact:
        nav.append({'label': 'Contact', 'anchor': 'contact'})
    return {
        'site': settings_obj,
        'nav_links': nav,
        'social_links': SocialLink.objects.filter(is_active=True),
    }
