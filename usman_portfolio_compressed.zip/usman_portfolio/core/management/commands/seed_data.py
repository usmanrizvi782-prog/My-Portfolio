"""Fill the database with the content of Muhammad Usman's CV.

Safe to run more than once: existing rows are never overwritten, so anything you
edit in the dashboard stays as you left it.  Run:  python manage.py seed_data
"""
from pathlib import Path

from django.conf import settings
from django.core.files.base import ContentFile
from django.core.management.base import BaseCommand
from django.db import transaction
from django.utils.text import slugify

from core.models import SiteSettings
from experience.models import Education, Experience
from projects.models import Project, Technology
from skills.models import Skill, SkillCategory

ASSETS = Path(settings.BASE_DIR) / 'seed_assets'

INTERESTS = """Python and Django web development
Database-driven applications
E-commerce operations and data management
UI/UX design
Video editing and digital content"""

SKILLS = [
    ('Programming & Development', 'Web development skills.', [
        ('Python', 'fa-brands fa-python', 'Python development for web applications.'),
        ('Django', 'fa-solid fa-server', 'Web development with the Django framework.'),
        ('HTML', 'fa-brands fa-html5', 'Structuring web pages and content.'),
        ('CSS', 'fa-brands fa-css3-alt', 'Styling and responsive page layouts.'),
        ('JavaScript', 'fa-brands fa-js', 'Adding interactivity to web pages.'),
        ('Database Management', 'fa-solid fa-database', 'Working with database-driven applications.'),
        ('Django ORM', 'fa-solid fa-table-cells', 'Modelling and querying data through Django models.'),
    ]),
    ('Professional Skills', 'Office, e-commerce and procurement skills.', [
        ('Advanced Microsoft Excel', 'fa-solid fa-file-excel', 'Data analysis, formulas, reporting and record management.'),
        ('Microsoft Office', 'fa-solid fa-file-word', 'Document preparation, formatting and office correspondence.'),
        ('Procurement Management', 'fa-solid fa-file-contract', 'Procurement documentation, bid processing and procedure compliance.'),
        ('Tender Management', 'fa-solid fa-gavel', 'Tender uploading on the EPADS (PPRA) and EPMS portals.'),
        ('E-commerce Management', 'fa-solid fa-cart-shopping', 'Product listing, catalog management and marketplace operations.'),
        ('Data Entry & Record Management', 'fa-solid fa-keyboard', 'Accurate data handling, filing and digital record keeping.'),
        ('UI/UX Design', 'fa-solid fa-pen-ruler', 'Understanding of user interface and user experience principles.'),
        ('Video Editing', 'fa-solid fa-film', 'Cutting, transitions, effects and social media video editing.'),
    ]),
]

EXPERIENCE = [
    dict(role='Computer Operator', company='SNGPL', start_year=2025, is_current=True, description="""Procurement and tender documentation.
EPADS (PPRA) and EPMS portal operations.
Price Comparison Statements.
Bid evaluation documentation.
Purchase Orders.
Vendor records and procurement data.
Excel reporting and documentation."""),
    dict(role='Assistant Manager', company='Daraz', description="""Product listing management.
Seller operations.
Product data management.
Marketplace standards."""),
    dict(role='Listing Manager', company='Noon', start_year=2022, description="""Product uploads.
Product title and description optimization.
Pricing and stock updates.
Catalog management."""),
    dict(role='Computer Operator', company='Orbi.pk', description="""Marketing posters and graphics.
Product listing management.
Digital content management."""),
    dict(role='Video Editing Intern', company='Adibl International', description="""Promotional video editing.
Social media video editing.
Video transitions and effects."""),
]

EDUCATION = [
    dict(degree='Matric', institution='Govt. MCHSS GM Abad', start_year=2020, end_year=2021),
    dict(degree='Intermediate', institution='AAIHS GM Abad', start_year=2023, end_year=2024),
    dict(degree='Economics with Data Science', institution='GC University', start_year=2026, period_label='2026...'),
    dict(degree='Full Stack Developer Course (Python with Django)', institution='Technosol',
         description='Full stack web development using Python and the Django framework.'),
]

DEMO_NOTE = ('This is a sample portfolio project idea, not completed client work. '
             'No repository or live demo has been published for it yet.')
PROJECTS = [
    dict(title='E-Commerce Management System', category='Web Application', featured=True,
         short='Sample project: a catalogue, stock and order management back office built with Django.',
         detail='A planned Django back office for an online store: product catalogue with categories, pricing and stock levels, customer orders with status tracking, and a simple sales summary.',
         tech=['Python', 'Django', 'HTML', 'CSS', 'JavaScript', 'SQLite']),
    dict(title='Personal Finance Dashboard', category='Dashboard',
         short='Sample project: track income and expenses with charts and monthly summaries.',
         detail='A planned dashboard where income and expenses are recorded by category and shown as Chart.js graphs with monthly totals.',
         tech=['Python', 'Django', 'Chart.js', 'Database']),
    dict(title='Procurement & Tender Management System', category='Business System', featured=True,
         short='Sample project: manage tenders, vendors, quotations and purchase orders in one place.',
         detail='A planned system inspired by day-to-day procurement documents: tender records, vendor lists, quotation comparison statements and purchase orders with status tracking.',
         tech=['Python', 'Django', 'PostgreSQL', 'JavaScript']),
    dict(title='Student Management System', category='Web Application',
         short='Sample project: students, courses and enrolments managed through Django.',
         detail='A planned application for managing student records, courses and enrolments with search and simple reports.',
         tech=['Python', 'Django', 'Bootstrap', 'SQLite']),
    dict(title='Inventory Management System', category='Business System',
         short='Sample project: products, stock movements and low-stock alerts.',
         detail='A planned inventory tool that records stock in and out, shows current levels and highlights items that need reordering.',
         tech=['Python', 'Django', 'Database', 'HTML', 'CSS']),
    dict(title='Developer Portfolio Website', category='Portfolio',
         short='This website: a database-driven 3D portfolio built with Django, Three.js and GSAP.',
         detail='The portfolio you are looking at: every section is stored in the database and edited through a custom Superadmin dashboard, with a Three.js hero scene and GSAP animations.',
         tech=['Python', 'Django', 'Three.js', 'GSAP']),
]


class Command(BaseCommand):
    help = "Load the CV content into the database (never overwrites existing rows)."

    @transaction.atomic
    def handle(self, *args, **options):
        site = SiteSettings.load()
        if not site.interests:
            site.interests = INTERESTS
            site.save()
        if not site.profile_picture and (ASSETS / 'profile.jpg').exists():
            site.profile_picture.save('profile.jpg', ContentFile((ASSETS / 'profile.jpg').read_bytes()))
        if not site.cv_file and (ASSETS / 'Muhammad_Usman_CV.pdf').exists():
            site.cv_file.save('Muhammad_Usman_CV.pdf', ContentFile((ASSETS / 'Muhammad_Usman_CV.pdf').read_bytes()))

        for cat_order, (cat_name, cat_desc, skills) in enumerate(SKILLS, start=1):
            category, _ = SkillCategory.objects.get_or_create(
                name=cat_name, defaults={'description': cat_desc, 'order': cat_order})
            for order, (name, icon, description) in enumerate(skills, start=1):
                Skill.objects.get_or_create(
                    category=category, name=name,
                    defaults={'icon_class': icon, 'description': description, 'order': order})

        for order, data in enumerate(EXPERIENCE, start=1):
            Experience.objects.get_or_create(
                role=data['role'], company=data['company'],
                defaults={**{k: v for k, v in data.items() if k not in ('role', 'company')}, 'order': order})

        for order, data in enumerate(EDUCATION, start=1):
            Education.objects.get_or_create(
                degree=data['degree'], institution=data['institution'],
                defaults={**{k: v for k, v in data.items() if k not in ('degree', 'institution')}, 'order': order})

        for order, data in enumerate(PROJECTS, start=1):
            slug = slugify(data['title'])
            project, created = Project.objects.get_or_create(
                slug=slug,
                defaults=dict(
                    title=data['title'], short_description=data['short'],
                    detailed_description=data['detail'] + '\n' + DEMO_NOTE,
                    category=data['category'], featured=data.get('featured', False),
                    is_demo=True, is_published=True, order=order))
            if created:
                for tech_name in data['tech']:
                    tech = Technology.objects.filter(name__iexact=tech_name).first() \
                        or Technology.objects.create(name=tech_name)
                    project.technologies.add(tech)
                thumb = ASSETS / 'thumbs' / f'{slug}.png'
                if thumb.exists():
                    project.thumbnail.save(f'{slug}.png', ContentFile(thumb.read_bytes()))

        self.stdout.write(self.style.SUCCESS('CV content loaded. Open /superadmin/ to edit it.'))
