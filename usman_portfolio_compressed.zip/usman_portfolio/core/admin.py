from django.contrib import admin

from .models import SiteSettings, SocialLink

admin.site.register(SiteSettings)


@admin.register(SocialLink)
class SocialLinkAdmin(admin.ModelAdmin):
    list_display = ('name', 'url', 'order', 'is_active')
    list_editable = ('order', 'is_active')
