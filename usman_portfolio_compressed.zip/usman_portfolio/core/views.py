import json

from django.db.models import Prefetch
from django.http import FileResponse, Http404, HttpResponse
from django.shortcuts import render
from django.template.defaultfilters import slugify
from django.utils.safestring import mark_safe
from django.views.decorators.http import require_GET

from contact.forms import ContactForm
from experience.models import Education, Experience
from projects.models import Project
from skills.models import Skill, SkillCategory

from .models import SiteSettings


def home(request):
    site = SiteSettings.load()

       # 'order' first (set from the dashboard), then oldest first, so cards keep the order you added them
    categories = SkillCategory.objects.order_by('order', 'id').prefetch_related(
        Prefetch('skills', queryset=Skill.objects.filter(is_active=True).order_by('order', 'id'),
                 to_attr='active_skills'))
    skill_categories = [c for c in categories if c.active_skills]

    experiences = Experience.objects.filter(is_active=True)
    educations = Education.objects.filter(is_active=True)
    projects = list(
        Project.objects.filter(is_published=True).prefetch_related('technologies'))
    project_categories = sorted({p.category for p in projects if p.category})

    stats = [
        {'label': 'Projects', 'value': len(projects)},
        {'label': 'Skills', 'value': sum(len(c.active_skills) for c in skill_categories)},
        {'label': 'Work experiences', 'value': experiences.count()},
        {'label': 'Education entries', 'value': educations.count()},
    ]

    jsonld = {
        '@context': 'https://schema.org',
        '@type': 'Person',
        'name': site.hero_name.title(),
        'jobTitle': site.hero_title.title(),
        'email': site.email,
        'url': request.build_absolute_uri('/'),
    }
    jsonld_safe = mark_safe(
        json.dumps(jsonld).replace('<', '\\u003c').replace('>', '\\u003e'))

    marquee_items = ['Python', 'Django', 'Django ORM', 'HTML', 'CSS', 'JavaScript',
                     'Database Management', 'REST APIs', 'UI/UX Design', 'Advanced Excel']
    return render(request, 'public/home.html', {
        'marquee_items': marquee_items,
        'skill_categories': skill_categories,
        'experiences': experiences,
        'educations': educations,
        'projects': projects,
        'project_categories': project_categories,
        'stats': stats,
        'contact_ts': ContactForm.make_timestamp(),
        'jsonld': jsonld_safe,
    })


@require_GET
def download_cv(request):
    site = SiteSettings.load()
    if not site.cv_file:
        raise Http404('The CV has not been uploaded yet.')
    try:
        handle = site.cv_file.open('rb')
    except (FileNotFoundError, ValueError):
        raise Http404('The CV file could not be found.')
    filename = f"{slugify(site.hero_name) or 'cv'}-cv.pdf"
    return FileResponse(handle, as_attachment=True, filename=filename,
                        content_type='application/pdf')


@require_GET
def robots_txt(request):
    lines = [
        'User-agent: *',
        'Disallow: /superadmin/',
        'Disallow: /django-admin/',
        'Allow: /',
        f"Sitemap: {request.build_absolute_uri('/sitemap.xml')}",
    ]
    return HttpResponse('\n'.join(lines) + '\n', content_type='text/plain')


def error_404(request, exception=None):
    return render(request, '404.html', status=404)
