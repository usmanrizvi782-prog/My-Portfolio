from django.utils.text import slugify


def unique_slug(instance, source, field='slug'):
    """Build a slug from ``source`` that is unique for the instance's model."""
    model = instance.__class__
    max_length = model._meta.get_field(field).max_length
    base = slugify(source)[:max_length] or model._meta.model_name
    slug, n = base, 2
    queryset = model._default_manager.exclude(pk=instance.pk)
    while queryset.filter(**{field: slug}).exists():
        suffix = f'-{n}'
        slug = f'{base[:max_length - len(suffix)]}{suffix}'
        n += 1
    return slug


def delete_file(field_file):
    """Remove a file from storage without touching the database row."""
    try:
        if field_file and field_file.name:
            field_file.delete(save=False)
    except Exception:  # missing file, permissions... never block a delete
        pass
