import time

from django.core import mail, signing
from django.core.cache import cache
from django.test import TestCase

from core.models import SiteSettings

from .forms import ContactForm
from .models import ContactMessage

AJAX = {'HTTP_X_REQUESTED_WITH': 'XMLHttpRequest'}


def valid_data(**overrides):
    data = {
        'name': 'Ali Khan', 'email': 'ali@example.com', 'subject': 'Hello',
        'message': 'I would like to talk about a project.', 'website': '',
        'ts': signing.dumps(int(time.time()) - 30, salt='contact-form'),
    }
    data.update(overrides)
    return data


class ContactFormTests(TestCase):
    def setUp(self):
        cache.clear()

    def test_valid_submission_is_saved_and_emailed(self):
        response = self.client.post('/contact/send/', valid_data(), **AJAX)
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.json()['ok'])
        self.assertEqual(ContactMessage.objects.count(), 1)
        self.assertFalse(ContactMessage.objects.get().is_read)
        self.assertEqual(len(mail.outbox), 1)
        self.assertEqual(mail.outbox[0].to, [SiteSettings.load().email])
        self.assertEqual(mail.outbox[0].reply_to, ['ali@example.com'])

    def test_invalid_fields_return_errors(self):
        response = self.client.post('/contact/send/', valid_data(email='nope', message='short'), **AJAX)
        self.assertEqual(response.status_code, 400)
        errors = response.json()['errors']
        self.assertIn('email', errors)
        self.assertIn('message', errors)
        self.assertEqual(ContactMessage.objects.count(), 0)

    def test_honeypot_is_silently_dropped(self):
        response = self.client.post('/contact/send/', valid_data(website='http://spam.example'), **AJAX)
        self.assertTrue(response.json()['ok'])
        self.assertEqual(ContactMessage.objects.count(), 0)

    def test_too_fast_and_forged_timestamps_are_rejected(self):
        fast = self.client.post('/contact/send/', valid_data(ts=ContactForm.make_timestamp()), **AJAX)
        self.assertEqual(fast.status_code, 400)
        forged = self.client.post('/contact/send/', valid_data(ts='not-signed'), **AJAX)
        self.assertEqual(forged.status_code, 400)
        self.assertEqual(ContactMessage.objects.count(), 0)

    def test_rate_limit(self):
        for _ in range(5):
            self.assertEqual(self.client.post('/contact/send/', valid_data(), **AJAX).status_code, 200)
        self.assertEqual(self.client.post('/contact/send/', valid_data(), **AJAX).status_code, 429)
        self.assertEqual(ContactMessage.objects.count(), 5)

    def test_plain_post_redirects_back_to_contact_section(self):
        response = self.client.post('/contact/send/', valid_data())
        self.assertRedirects(response, '/#contact', fetch_redirect_response=False)

    def test_get_is_not_allowed(self):
        self.assertEqual(self.client.get('/contact/send/').status_code, 405)

    def test_home_page_contains_form_and_contact_details(self):
        response = self.client.get('/')
        self.assertContains(response, 'id="contact-form"')
        self.assertContains(response, 'usmanrizvi561@gmail.com')
        self.assertContains(response, '+92-3700295134')
