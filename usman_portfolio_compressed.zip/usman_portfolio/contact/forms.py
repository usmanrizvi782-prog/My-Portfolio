import time

from django import forms
from django.core import signing

MIN_SECONDS_TO_FILL = 3
MAX_FORM_AGE = 60 * 60 * 6


class ContactForm(forms.Form):
    name = forms.CharField(max_length=120, strip=True)
    email = forms.EmailField(max_length=254)
    subject = forms.CharField(max_length=200, strip=True)
    message = forms.CharField(min_length=10, max_length=5000, strip=True)
    # Spam protection: bots tend to fill this hidden "honeypot" field...
    website = forms.CharField(required=False)
    # ...and submit instantly. The timestamp is signed so it cannot be forged.
    ts = forms.CharField(required=False)

    error_messages = {
        'stale': 'This form has expired. Please reload the page and try again.',
        'fast': 'That was very quick. Please wait a moment and send again.',
    }

    @staticmethod
    def make_timestamp():
        return signing.dumps(int(time.time()), salt='contact-form')

    def clean_ts(self):
        value = self.cleaned_data.get('ts', '')
        try:
            created = signing.loads(value, salt='contact-form', max_age=MAX_FORM_AGE)
        except signing.BadSignature:
            raise forms.ValidationError(self.error_messages['stale'])
        if time.time() - created < MIN_SECONDS_TO_FILL:
            raise forms.ValidationError(self.error_messages['fast'])
        return value
