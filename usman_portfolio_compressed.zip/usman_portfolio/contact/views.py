import logging

from django.contrib import messages
from django.core.cache import cache
from django.core.mail import EmailMessage
from django.http import JsonResponse
from django.shortcuts import redirect
from django.urls import reverse
from django.views.decorators.http import require_POST

from core.models import SiteSettings

from .forms import ContactForm
from .models import ContactMessage

logger = logging.getLogger(__name__)

RATE_LIMIT = 5          # messages ...
RATE_WINDOW = 60 * 60   # ... per hour per IP address


def _send_notification(contact_message):
    """Email the site owner. Failures are logged but never shown to the visitor."""
    body = (
        f'New message from your portfolio\n\n'
        f'Name: {contact_message.name}\n'
        f'Email: {contact_message.email}\n'
        f'Subject: {contact_message.subject}\n\n'
        f'{contact_message.message}\n'
    )
    try:
        EmailMessage(
            subject=f'[Portfolio] {contact_message.subject}',
            body=body,
            to=[SiteSettings.load().email],
            reply_to=[contact_message.email],
        ).send(fail_silently=False)
    except Exception:
        logger.exception('Could not send the contact notification email.')


@require_POST
def submit(request):
    wants_json = request.headers.get('x-requested-with') == 'XMLHttpRequest'
    ip = request.META.get('REMOTE_ADDR') or None

    def respond(ok, text, status=200, errors=None):
        if wants_json:
            return JsonResponse({'ok': ok, 'message': text, 'errors': errors or {}}, status=status)
        (messages.success if ok else messages.error)(request, text)
        return redirect(reverse('home') + '#contact')

    key = f'contact-rate:{ip}'
    if cache.get(key, 0) >= RATE_LIMIT:
        return respond(False, 'Too many messages from this connection. Please try again later.', 429)

    form = ContactForm(request.POST)
    if not form.is_valid():
        errors = {field: [str(e) for e in errs] for field, errs in form.errors.items()}
        return respond(False, 'Please fix the highlighted fields.', 400, errors)

    if form.cleaned_data.get('website'):
        # Honeypot filled: pretend it worked so bots learn nothing.
        return respond(True, 'Thank you! Your message has been sent.')

    saved = ContactMessage.objects.create(
        name=form.cleaned_data['name'],
        email=form.cleaned_data['email'],
        subject=form.cleaned_data['subject'],
        message=form.cleaned_data['message'],
        ip_address=ip,
    )
    _send_notification(saved)
    cache.set(key, cache.get(key, 0) + 1, RATE_WINDOW)
    return respond(True, 'Thank you! Your message has been sent.')
