from django.urls import path

from . import views

urlpatterns = [
    path('send/', views.submit, name='contact_submit'),
]
