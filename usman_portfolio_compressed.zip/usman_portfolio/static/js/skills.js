/* Skills: click a card or badge to open its details in a modal (native <dialog>). */
(function () {
  'use strict';
  var cards = document.querySelectorAll('[data-skill-open]');
  Array.prototype.forEach.call(cards, function (card) {
    var dlg = document.getElementById(card.getAttribute('data-skill-open'));
    if (!dlg || typeof dlg.showModal !== 'function') return;

    function open() { dlg.showModal(); document.documentElement.classList.add('modal-open'); }
    card.addEventListener('click', open);
    card.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); open(); }
    });
    dlg.addEventListener('click', function (e) {
      if (e.target === dlg || e.target.closest('[data-close]')) dlg.close();
    });
    dlg.addEventListener('close', function () {
      document.documentElement.classList.remove('modal-open');
      card.focus({ preventScroll: true });
    });
  });
})();