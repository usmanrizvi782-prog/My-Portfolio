/* Dashboard behaviour: theme toggle (stored separately from the public site) and mobile sidebar. */
(function () {
  'use strict';
  var root = document.documentElement;

  var themeBtn = document.getElementById('dash-theme');
  if (themeBtn) {
    themeBtn.addEventListener('click', function () {
      var next = root.getAttribute('data-dash-theme') === 'light' ? 'dark' : 'light';
      root.setAttribute('data-dash-theme', next);
      try { localStorage.setItem('dashTheme', next); } catch (e) {}
    });
  }

  var sidebar = document.getElementById('sidebar');
  var scrim = document.getElementById('scrim');
  var menuBtn = document.getElementById('menu-btn');
  function toggle(open) {
    if (!sidebar) return;
    sidebar.classList.toggle('open', open);
    if (scrim) scrim.classList.toggle('open', open);
  }
  if (menuBtn) menuBtn.addEventListener('click', function () { toggle(!sidebar.classList.contains('open')); });
  if (scrim) scrim.addEventListener('click', function () { toggle(false); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') toggle(false); });
})();
