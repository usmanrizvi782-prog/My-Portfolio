/* Public site behaviour: theme, navigation, loader, GSAP animations, filters,
   tilt cards, lightbox and the AJAX contact form. Everything degrades
   gracefully: without GSAP the content simply stays visible. */
(function () {
  'use strict';

  var root = document.documentElement;
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var finePointer = window.matchMedia('(hover: hover) and (pointer: fine)').matches;
  function $(selector, ctx) { return (ctx || document).querySelector(selector); }
  function $$(selector, ctx) { return Array.prototype.slice.call((ctx || document).querySelectorAll(selector)); }

  /* ------------------------------------------------------------ theme */
  var themeBtn = $('#theme-toggle');
  if (themeBtn) {
    themeBtn.addEventListener('click', function () {
      var next = root.getAttribute('data-theme') === 'light' ? 'dark' : 'light';
      if (!reduce) {
        root.classList.add('theme-anim');
        setTimeout(function () { root.classList.remove('theme-anim'); }, 500);
      }
      root.setAttribute('data-theme', next);
      try { localStorage.setItem('theme', next); } catch (e) {}
      window.dispatchEvent(new CustomEvent('themechange', { detail: next }));
    });
  }

  /* ------------------------------------------------------------ navigation */
  var nav = $('#nav');
  function onScroll() { if (nav) nav.classList.toggle('scrolled', window.scrollY > 24); }
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  var burger = $('#nav-burger');
  var links = $('#nav-links');
  function closeMenu() {
    if (!links) return;
    links.classList.remove('open');
    if (burger) { burger.setAttribute('aria-expanded', 'false'); burger.setAttribute('aria-label', 'Open menu'); }
  }
  if (burger && links) {
    burger.addEventListener('click', function () {
      var open = links.classList.toggle('open');
      burger.setAttribute('aria-expanded', open ? 'true' : 'false');
      burger.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
    });
    links.addEventListener('click', function (e) { if (e.target.closest('a')) closeMenu(); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeMenu(); });
  }

  // highlight the nav link of the section that is on screen (home page only)
  if ('IntersectionObserver' in window) {
    var spyLinks = $$('[data-spy]');
    var spy = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (!entry.isIntersecting) return;
        spyLinks.forEach(function (a) {
          a.classList.toggle('active', a.getAttribute('data-spy') === entry.target.id);
        });
      });
    }, { rootMargin: '-45% 0px -50% 0px' });
    spyLinks.forEach(function (a) {
      var section = document.getElementById(a.getAttribute('data-spy'));
      if (section) spy.observe(section);
    });
  }

  /* ------------------------------------------------------------ loader */
  var loader = $('#loader');
  var finished = false;
  function finishLoader() {
    if (finished) return;
    finished = true;
    if (loader) loader.classList.add('done');
    window.dispatchEvent(new Event('portfolio:ready'));
  }
  var startedAt = performance.now();
  function whenLoaded() {
    var wait = reduce ? 0 : Math.max(0, 700 - (performance.now() - startedAt));
    setTimeout(finishLoader, wait);
  }
  if (document.readyState === 'complete') whenLoaded(); else window.addEventListener('load', whenLoaded);
  setTimeout(finishLoader, 5000); // safety net if a resource hangs

  /* ------------------------------------------------------------ page transitions */
  document.addEventListener('click', function (e) {
    if (reduce || e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
    var a = e.target.closest('a');
    if (!a || (a.target && a.target !== '_self') || a.hasAttribute('download') || a.hasAttribute('data-no-transition')) return;
    var url;
    try { url = new URL(a.href, window.location.href); } catch (err) { return; }
    if (url.origin !== window.location.origin) return;
    if (url.pathname === window.location.pathname && url.search === window.location.search) return; // same-page anchor
    e.preventDefault();
    document.body.classList.add('leaving');
    setTimeout(function () { window.location.href = url.href; }, 220);
  });
  window.addEventListener('pageshow', function (e) { if (e.persisted) document.body.classList.remove('leaving'); });

  /* ------------------------------------------------------------ cursor glow */
  var glow = $('.cursor-glow');
  if (glow && finePointer && !reduce) {
    var gx = 0, gy = 0, gtx = 0, gty = 0;
    window.addEventListener('pointermove', function (e) {
      gtx = e.clientX; gty = e.clientY; glow.classList.add('on');
    }, { passive: true });
    document.addEventListener('pointerleave', function () { glow.classList.remove('on'); });
    (function follow() {
      gx += (gtx - gx) * 0.12; gy += (gty - gy) * 0.12;
      glow.style.transform = 'translate3d(' + gx.toFixed(1) + 'px,' + gy.toFixed(1) + 'px,0)';
      requestAnimationFrame(follow);
    })();
  }

  /* ------------------------------------------------------------ 3D tilt cards */
  if (finePointer && !reduce) {
    $$('.tilt').forEach(function (el) {
      el.addEventListener('pointermove', function (e) {
        var r = el.getBoundingClientRect();
        var px = (e.clientX - r.left) / r.width;
        var py = (e.clientY - r.top) / r.height;
        el.style.setProperty('--ry', ((px - 0.5) * 14).toFixed(2) + 'deg');
        el.style.setProperty('--rx', ((0.5 - py) * 14).toFixed(2) + 'deg');
        el.style.setProperty('--mx', (px * 100).toFixed(1) + '%');
        el.style.setProperty('--my', (py * 100).toFixed(1) + '%');
        el.classList.add('is-hover');
      });
      el.addEventListener('pointerleave', function () {
        el.style.setProperty('--rx', '0deg');
        el.style.setProperty('--ry', '0deg');
        el.classList.remove('is-hover');
      });
    });
  }

  /* ------------------------------------------------------------ project filters */
  var filterButtons = $$('.filter');
  filterButtons.forEach(function (btn) {
    btn.addEventListener('click', function () {
      var wanted = btn.getAttribute('data-filter');
      filterButtons.forEach(function (b) { b.classList.toggle('is-active', b === btn); });
      $$('#project-grid > li[data-category]').forEach(function (li) {
        var show = wanted === 'all' || li.getAttribute('data-category') === wanted;
        li.hidden = !show;
        if (show) {
          li.style.opacity = 1; li.style.transform = 'none';
          if (!reduce) { li.classList.remove('pop-in'); void li.offsetWidth; li.classList.add('pop-in'); }
        }
      });
      if (window.ScrollTrigger) window.ScrollTrigger.refresh();
    });
  });

  /* ------------------------------------------------------------ lightbox (image zoom) */
  var lightbox = $('#lightbox');
  if (lightbox) {
    var lightboxImg = $('img', lightbox);
    var lastFocus = null;
    var closeLightbox = function () {
      lightbox.hidden = true; lightboxImg.removeAttribute('src');
      if (lastFocus) lastFocus.focus();
    };
    $$('[data-zoom]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        lastFocus = btn;
        lightboxImg.src = btn.getAttribute('data-zoom');
        lightbox.hidden = false;
        $('.lightbox-close', lightbox).focus();
      });
    });
    lightbox.addEventListener('click', closeLightbox);
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !lightbox.hidden) closeLightbox(); });
  }

  /* ------------------------------------------------------------ animated counters */
  if ('IntersectionObserver' in window && !reduce) {
    var counters = $$('[data-count]');
    var counterObserver = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (!entry.isIntersecting) return;
        counterObserver.unobserve(entry.target);
        var el = entry.target;
        var end = parseInt(el.getAttribute('data-count'), 10) || 0;
        var begin = performance.now();
        (function tick(now) {
          var p = Math.min(1, (now - begin) / 1200);
          el.textContent = Math.round(end * (1 - Math.pow(1 - p, 3)));
          if (p < 1) requestAnimationFrame(tick);
        })(begin);
      });
    }, { threshold: 0.6 });
    counters.forEach(function (el) { el.textContent = '0'; counterObserver.observe(el); });
  }

  /* ------------------------------------------------------------ contact form (AJAX) */
  var form = $('#contact-form');
  if (form && window.fetch) {
    var live = $('#contact-live');
    var submitBtn = $('#contact-submit');
    var clearErrors = function () {
      $$('[data-error-for]', form).forEach(function (p) { p.textContent = ''; });
      $$('.field', form).forEach(function (f) { f.classList.remove('has-error'); });
    };
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      clearErrors();
      submitBtn.disabled = true;
      live.className = 'form-live';
      live.textContent = 'Sending…';
      fetch(form.action, {
        method: 'POST', body: new FormData(form), credentials: 'same-origin',
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
      }).then(function (response) {
        return response.json().catch(function () {
          return { ok: false, message: 'Something went wrong. Please try again.', errors: {} };
        });
      }).then(function (data) {
        if (data.ok) {
          live.classList.add('ok');
          live.textContent = data.message;
          form.reset();
        } else {
          live.classList.add('err');
          live.textContent = data.message;
          Object.keys(data.errors || {}).forEach(function (name) {
            var holder = $('[data-error-for="' + name + '"]', form);
            if (holder) {
              holder.textContent = data.errors[name].join(' ');
              var field = holder.closest('.field');
              if (field) field.classList.add('has-error');
            }
          });
        }
      }).catch(function () {
        live.classList.add('err');
        live.textContent = 'Network error. Please try again.';
      }).then(function () { submitBtn.disabled = false; });
    });
  }

  /* ------------------------------------------------------------ GSAP animations */
  function initGsap() {
    if (reduce || !window.gsap) return;
    var gsap = window.gsap;
    var hasST = !!window.ScrollTrigger;
    if (hasST) gsap.registerPlugin(window.ScrollTrigger);
    root.classList.add('js-anim');

    // scroll reveals
    if (hasST) {
      window.ScrollTrigger.batch('.reveal', {
        start: 'top 90%', once: true,
        onEnter: function (batch) {
          gsap.to(batch, { opacity: 1, y: 0, duration: 0.85, ease: 'power3.out', stagger: 0.09, overwrite: true });
        }
      });
    } else {
      gsap.to('.reveal', { opacity: 1, y: 0, stagger: 0.05 });
    }

    // timeline line draws as you scroll
    var timeline = $('.timeline');
    if (timeline && hasST) {
      timeline.style.setProperty('--p', 0);
      gsap.to(timeline, {
        '--p': 1, ease: 'none',
        scrollTrigger: { trigger: timeline, start: 'top 70%', end: 'bottom 60%', scrub: true }
      });
    }

    // hero entrance: the name rises letter by letter once the loader is gone
    var nameEl = $('#hero-name');
    if (nameEl) {
      var words = nameEl.textContent.trim().split(/\s+/);
      nameEl.textContent = '';
      words.forEach(function (word, index) {
        var wordEl = document.createElement('span');
        wordEl.className = 'word';
        wordEl.setAttribute('aria-hidden', 'true');
        word.split('').forEach(function (ch) {
          var charEl = document.createElement('span');
          charEl.className = 'char';
          charEl.textContent = ch;
          wordEl.appendChild(charEl);
        });
        nameEl.appendChild(wordEl);
        if (index < words.length - 1) nameEl.appendChild(document.createTextNode(' '));
      });
      var rest = $$('.hero-pills, .hero-title, .hero-typed, .hero-tagline, .hero-actions, .hero-social');
      gsap.set('.hero-name .char', { yPercent: 115, opacity: 0 });
      gsap.set(rest, { opacity: 0, y: 26 });
      gsap.set('.hero-visual', { opacity: 0, scale: .86 });
      gsap.set('.scroll-cue', { opacity: 0 });
      var play = function () {
        var tl = gsap.timeline({ defaults: { ease: 'power4.out' } });
        tl.to('.hero-pills', { opacity: 1, y: 0, duration: .8, clearProps: 'transform' })
          .to('.hero-name .char', { yPercent: 0, opacity: 1, duration: 1, stagger: 0.035 }, '-=0.5')
          .to('.hero-visual', { opacity: 1, scale: 1, duration: 1.3, ease: 'expo.out', clearProps: 'transform' }, '-=1.1')
          .to(rest.filter(function (el) { return !el.classList.contains('hero-pills'); }),
              { opacity: 1, y: 0, duration: 0.9, stagger: 0.1, clearProps: 'transform' }, '-=0.7')
          .to('.scroll-cue', { opacity: 1, duration: 0.8 }, '-=0.2');
      };
      if (finished) play(); else window.addEventListener('portfolio:ready', play, { once: true });
    }
  }

  if (window.gsap) initGsap();
  else window.addEventListener('load', initGsap);
})();
