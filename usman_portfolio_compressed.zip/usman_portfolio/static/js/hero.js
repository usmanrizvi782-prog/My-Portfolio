/* Hero extras: animated network background (canvas) + typing effect.
   - Pauses when the hero is off screen or the tab is hidden.
   - prefers-reduced-motion: draws one still frame, shows the first typed word.
   - Colours follow the theme through the CSS variable --dot. */
(function () {
  'use strict';
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ------------------------------------------------ typing effect */
  var typed = document.getElementById('typed');
  if (typed) {
    var words = (typed.getAttribute('data-words') || '').split('|').filter(Boolean);
    if (!words.length) words = [typed.textContent];
    if (reduce) {
      typed.textContent = words[0];
    } else {
      var w = 0, c = 0, deleting = false;
      (function tick() {
        var word = words[w];
        c += deleting ? -1 : 1;
        typed.textContent = word.slice(0, c);
        var delay = deleting ? 45 : 95;
        if (!deleting && c === word.length) { deleting = true; delay = 1600; }
        else if (deleting && c === 0) { deleting = false; w = (w + 1) % words.length; delay = 400; }
        setTimeout(tick, delay);
      })();
    }
  }

  /* ------------------------------------------------ network background */
  var canvas = document.getElementById('hero-canvas');
  if (!canvas || !canvas.getContext) return;
  var ctx = canvas.getContext('2d');
  var hero = canvas.closest('.hero');
  var dpr = Math.min(window.devicePixelRatio || 1, 2);
  var W = 0, H = 0, nodes = [], running = true, mouse = { x: -9999, y: -9999 };
  var rgb = '160,150,255';

  function readColor() {
    var v = getComputedStyle(document.documentElement).getPropertyValue('--dot').trim();
    if (v) rgb = v;
  }
  function resize() {
    var r = hero.getBoundingClientRect();
    W = r.width; H = r.height;
    canvas.width = W * dpr; canvas.height = H * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    var count = Math.max(28, Math.min(90, Math.round(W * H / 16000)));
    nodes = [];
    for (var i = 0; i < count; i++) {
      nodes.push({
        x: Math.random() * W, y: Math.random() * H,
        vx: (Math.random() - .5) * .35, vy: (Math.random() - .5) * .35,
        r: Math.random() * 1.6 + .8
      });
    }
  }
  function draw() {
    ctx.clearRect(0, 0, W, H);
    var maxD = Math.min(150, W / 6), i, j, a, b, dx, dy, d;
    for (i = 0; i < nodes.length; i++) {
      a = nodes[i];
      if (!reduce) {
        a.x += a.vx; a.y += a.vy;
        if (a.x < 0 || a.x > W) a.vx *= -1;
        if (a.y < 0 || a.y > H) a.vy *= -1;
        dx = a.x - mouse.x; dy = a.y - mouse.y; d = Math.sqrt(dx * dx + dy * dy);
        if (d < 120 && d > 0) { a.x += dx / d * 1.1; a.y += dy / d * 1.1; }
      }
      for (j = i + 1; j < nodes.length; j++) {
        b = nodes[j]; dx = a.x - b.x; dy = a.y - b.y; d = Math.sqrt(dx * dx + dy * dy);
        if (d < maxD) {
          ctx.strokeStyle = 'rgba(' + rgb + ',' + ((1 - d / maxD) * .32).toFixed(3) + ')';
          ctx.lineWidth = 1;
          ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
        }
      }
      ctx.fillStyle = 'rgba(' + rgb + ',.75)';
      ctx.beginPath(); ctx.arc(a.x, a.y, a.r, 0, 6.2832); ctx.fill();
    }
  }
  function loop() {
    if (running && !document.hidden) draw();
    if (!reduce) requestAnimationFrame(loop);
  }

  readColor(); resize(); draw();
  var rt; window.addEventListener('resize', function () { clearTimeout(rt); rt = setTimeout(function () { resize(); draw(); }, 150); });
  window.addEventListener('themechange', function () { setTimeout(function () { readColor(); draw(); }, 60); });
  hero.addEventListener('pointermove', function (e) { var r = hero.getBoundingClientRect(); mouse.x = e.clientX - r.left; mouse.y = e.clientY - r.top; });
  hero.addEventListener('pointerleave', function () { mouse.x = mouse.y = -9999; });
  if ('IntersectionObserver' in window) new IntersectionObserver(function (en) { running = en[0].isIntersecting; }).observe(hero);
  if (!reduce) loop();
})();
