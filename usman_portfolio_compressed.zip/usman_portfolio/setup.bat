@echo off
REM One-command local setup for Windows.  Double-click or run:  setup.bat
python -m venv venv
call venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
if not exist .env copy .env.example .env
python manage.py makemigrations core skills experience projects contact
python manage.py migrate
python manage.py seed_data
echo.
echo Create your Superadmin account (you will log in at /superadmin/login/):
python manage.py createsuperuser
echo.
echo Starting the server at http://127.0.0.1:8000/
python manage.py runserver
