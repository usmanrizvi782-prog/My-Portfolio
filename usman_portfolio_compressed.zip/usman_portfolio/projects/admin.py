from django.contrib import admin

from .models import Project, ProjectImage, Technology


class ProjectImageInline(admin.TabularInline):
    model = ProjectImage
    extra = 1


@admin.register(Project)
class ProjectAdmin(admin.ModelAdmin):
    list_display = ('title', 'category', 'is_published', 'featured', 'is_demo', 'order')
    list_editable = ('is_published', 'featured', 'order')
    list_filter = ('is_published', 'featured', 'category')
    search_fields = ('title', 'short_description')
    prepopulated_fields = {'slug': ('title',)}
    inlines = [ProjectImageInline]


admin.site.register(Technology)
