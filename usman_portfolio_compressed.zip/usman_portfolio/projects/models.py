from django.db import models
from django.db.models.signals import post_delete
from django.dispatch import receiver
from django.urls import reverse
from django.utils import timezone

from core.utils import delete_file, unique_slug


class Technology(models.Model):
    name = models.CharField(max_length=60, unique=True)
    slug = models.SlugField(max_length=70, unique=True, blank=True)

    class Meta:
        ordering = ['name']
        verbose_name_plural = 'Technologies'

    def __str__(self):
        return self.name

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = unique_slug(self, self.name)
        super().save(*args, **kwargs)


class Project(models.Model):
    title = models.CharField(max_length=140)
    slug = models.SlugField(max_length=160, unique=True, blank=True,
                            help_text='Used in the project URL. Leave empty to generate it from the title.')
    short_description = models.CharField(max_length=300)
    detailed_description = models.TextField(blank=True)
    thumbnail = models.ImageField(upload_to='projects/thumbnails/', blank=True)
    technologies = models.ManyToManyField(Technology, blank=True, related_name='projects')
    github_url = models.URLField(blank=True)
    live_url = models.URLField(blank=True)
    category = models.CharField(max_length=80, blank=True)
    featured = models.BooleanField(default=False)
    published_date = models.DateField(default=timezone.localdate)
    order = models.PositiveIntegerField(default=0)
    is_published = models.BooleanField(default=True)
    is_demo = models.BooleanField(
        default=False, help_text='Show a "Sample project" badge (use for demo ideas, not real work).')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['order', '-published_date']

    def __str__(self):
        return self.title

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = unique_slug(self, self.title)
        super().save(*args, **kwargs)

    def get_absolute_url(self):
        return reverse('project_detail', kwargs={'slug': self.slug})

    @property
    def paragraphs(self):
        return [p.strip() for p in self.detailed_description.splitlines() if p.strip()]


class ProjectImage(models.Model):
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name='images')
    image = models.ImageField(upload_to='projects/screenshots/')
    caption = models.CharField(max_length=160, blank=True)
    order = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ['order', 'id']

    def __str__(self):
        return f'{self.project.title} – image {self.pk}'


@receiver(post_delete, sender=Project)
def _remove_thumbnail(sender, instance, **kwargs):
    delete_file(instance.thumbnail)


@receiver(post_delete, sender=ProjectImage)
def _remove_screenshot(sender, instance, **kwargs):
    delete_file(instance.image)
