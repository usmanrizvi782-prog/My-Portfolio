from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse

from .models import Project


def project_list(request):
    return redirect(reverse('home') + '#projects')


def project_detail(request, slug):
    project = get_object_or_404(
        Project.objects.prefetch_related('technologies', 'images'), slug=slug, is_published=True)
    others = Project.objects.filter(is_published=True).exclude(pk=project.pk)[:3]
    return render(request, 'public/project_detail.html', {'project': project, 'others': others})
